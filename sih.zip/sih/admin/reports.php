<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Get date range from request
$start_date = $_GET['start_date'] ?? date('Y-m-01'); // First day of current month
$end_date = $_GET['end_date'] ?? date('Y-m-d'); // Today
$report_type = $_GET['report_type'] ?? 'overview';

try {
    // Overview Statistics
    $overview_stats = [];
    
    // User registration trends
    $stmt = $pdo->prepare("SELECT 
                          DATE(created_at) as date,
                          COUNT(*) as registrations,
                          SUM(CASE WHEN user_type = 'patient' THEN 1 ELSE 0 END) as patients,
                          SUM(CASE WHEN user_type = 'doctor' THEN 1 ELSE 0 END) as doctors
                          FROM users 
                          WHERE DATE(created_at) BETWEEN ? AND ?
                          GROUP BY DATE(created_at)
                          ORDER BY date DESC");
    $stmt->execute([$start_date, $end_date]);
    $registration_trends = $stmt->fetchAll();
    
    // Medical records by date
    $stmt = $pdo->prepare("SELECT 
                          DATE(visit_date) as date,
                          COUNT(*) as records_count,
                          COUNT(DISTINCT patient_id) as unique_patients
                          FROM medical_records 
                          WHERE DATE(visit_date) BETWEEN ? AND ?
                          GROUP BY DATE(visit_date)
                          ORDER BY date DESC");
    $stmt->execute([$start_date, $end_date]);
    $medical_records_trends = $stmt->fetchAll();
    
    // Appointment statistics
    $stmt = $pdo->prepare("SELECT 
                          DATE(appointment_date) as date,
                          COUNT(*) as total_appointments,
                          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                          SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
                          FROM appointments 
                          WHERE DATE(appointment_date) BETWEEN ? AND ?
                          GROUP BY DATE(appointment_date)
                          ORDER BY date DESC");
    $stmt->execute([$start_date, $end_date]);
    $appointment_trends = $stmt->fetchAll();
    
    // Migrant worker demographics
    $stmt = $pdo->query("SELECT 
                        country_of_origin,
                        COUNT(*) as count,
                        AVG(YEAR(CURDATE()) - YEAR(date_of_birth)) as avg_age
                        FROM patients 
                        WHERE country_of_origin IS NOT NULL AND country_of_origin != ''
                        GROUP BY country_of_origin 
                        ORDER BY count DESC 
                        LIMIT 15");
    $demographics = $stmt->fetchAll();
    
    // Language preferences
    $stmt = $pdo->query("SELECT 
                        preferred_language,
                        COUNT(*) as count
                        FROM patients 
                        WHERE preferred_language IS NOT NULL AND preferred_language != ''
                        GROUP BY preferred_language 
                        ORDER BY count DESC");
    $language_stats = $stmt->fetchAll();
    
    // Health conditions analysis
    $stmt = $pdo->prepare("SELECT 
                          diagnosis,
                          COUNT(*) as frequency
                          FROM medical_records 
                          WHERE diagnosis IS NOT NULL AND diagnosis != ''
                          AND DATE(visit_date) BETWEEN ? AND ?
                          GROUP BY diagnosis 
                          ORDER BY frequency DESC 
                          LIMIT 20");
    $stmt->execute([$start_date, $end_date]);
    $health_conditions = $stmt->fetchAll();
    
    // System usage statistics
    $stmt = $pdo->prepare("SELECT 
                          DATE(created_at) as date,
                          COUNT(*) as activities
                          FROM system_logs 
                          WHERE DATE(created_at) BETWEEN ? AND ?
                          GROUP BY DATE(created_at)
                          ORDER BY date DESC");
    $stmt->execute([$start_date, $end_date]);
    $system_usage = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $registration_trends = $medical_records_trends = $appointment_trends = [];
    $demographics = $language_stats = $health_conditions = $system_usage = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>Admin Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-1"></i>User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="reports.php">
                            <i class="fas fa-chart-bar me-1"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="system_logs.php">
                            <i class="fas fa-list-alt me-1"></i>System Logs
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-shield me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4><i class="fas fa-chart-bar me-2"></i>System Reports & Analytics</h4>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Start Date</label>
                                <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">End Date</label>
                                <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Report Type</label>
                                <select class="form-select" name="report_type">
                                    <option value="overview" <?php echo $report_type === 'overview' ? 'selected' : ''; ?>>Overview</option>
                                    <option value="demographics" <?php echo $report_type === 'demographics' ? 'selected' : ''; ?>>Demographics</option>
                                    <option value="health" <?php echo $report_type === 'health' ? 'selected' : ''; ?>>Health Trends</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">&nbsp;</label>
                                <button type="submit" class="btn btn-primary d-block w-100">
                                    <i class="fas fa-search me-1"></i>Generate Report
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Registration Trends -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-user-plus me-2"></i>User Registration Trends</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="registrationChart" height="100"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-globe me-2"></i>Top Countries</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($demographics)): ?>
                        <p class="text-muted text-center">No demographic data available</p>
                        <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach (array_slice($demographics, 0, 8) as $demo): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <strong><?php echo htmlspecialchars($demo['country_of_origin']); ?></strong>
                                    <br><small class="text-muted">Avg age: <?php echo round($demo['avg_age']); ?> years</small>
                                </div>
                                <span class="badge bg-primary rounded-pill"><?php echo $demo['count']; ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Medical Records and Appointments -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-file-medical me-2"></i>Medical Records Activity</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="recordsChart" height="150"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-calendar-check me-2"></i>Appointment Statistics</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="appointmentsChart" height="150"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Language Preferences and Health Conditions -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-language me-2"></i>Language Preferences</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($language_stats)): ?>
                        <p class="text-muted text-center">No language data available</p>
                        <?php else: ?>
                        <canvas id="languageChart" height="150"></canvas>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-stethoscope me-2"></i>Common Health Conditions</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($health_conditions)): ?>
                        <p class="text-muted text-center">No health condition data for selected period</p>
                        <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach (array_slice($health_conditions, 0, 10) as $condition): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <span><?php echo htmlspecialchars($condition['diagnosis']); ?></span>
                                <span class="badge bg-warning rounded-pill"><?php echo $condition['frequency']; ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Export Options -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-download me-2"></i>Export Options</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <a href="../export_data.php" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-users fa-2x d-block mb-2"></i>
                                    Export Patient Data
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="../export_data.php" class="btn btn-outline-success w-100">
                                    <i class="fas fa-file-medical fa-2x d-block mb-2"></i>
                                    Export Medical Records
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="../export_data.php" class="btn btn-outline-info w-100">
                                    <i class="fas fa-calendar fa-2x d-block mb-2"></i>
                                    Export Appointments
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <button onclick="window.print()" class="btn btn-outline-secondary w-100">
                                    <i class="fas fa-print fa-2x d-block mb-2"></i>
                                    Print Report
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Registration Trends Chart
        const registrationData = <?php echo json_encode($registration_trends); ?>;
        const regCtx = document.getElementById('registrationChart').getContext('2d');
        new Chart(regCtx, {
            type: 'line',
            data: {
                labels: registrationData.map(item => item.date),
                datasets: [{
                    label: 'Total Registrations',
                    data: registrationData.map(item => item.registrations),
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }, {
                    label: 'Patients',
                    data: registrationData.map(item => item.patients),
                    borderColor: 'rgb(54, 162, 235)',
                    tension: 0.1
                }, {
                    label: 'Doctors',
                    data: registrationData.map(item => item.doctors),
                    borderColor: 'rgb(255, 99, 132)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Medical Records Chart
        const recordsData = <?php echo json_encode($medical_records_trends); ?>;
        const recordsCtx = document.getElementById('recordsChart').getContext('2d');
        new Chart(recordsCtx, {
            type: 'bar',
            data: {
                labels: recordsData.map(item => item.date),
                datasets: [{
                    label: 'Medical Records',
                    data: recordsData.map(item => item.records_count),
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Appointments Chart
        const appointmentsData = <?php echo json_encode($appointment_trends); ?>;
        const appointmentsCtx = document.getElementById('appointmentsChart').getContext('2d');
        new Chart(appointmentsCtx, {
            type: 'bar',
            data: {
                labels: appointmentsData.map(item => item.date),
                datasets: [{
                    label: 'Completed',
                    data: appointmentsData.map(item => item.completed),
                    backgroundColor: 'rgba(75, 192, 192, 0.5)'
                }, {
                    label: 'Cancelled',
                    data: appointmentsData.map(item => item.cancelled),
                    backgroundColor: 'rgba(255, 99, 132, 0.5)'
                }, {
                    label: 'Pending',
                    data: appointmentsData.map(item => item.pending),
                    backgroundColor: 'rgba(255, 205, 86, 0.5)'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        stacked: true
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true
                    }
                }
            }
        });

        // Language Preferences Chart
        <?php if (!empty($language_stats)): ?>
        const languageData = <?php echo json_encode($language_stats); ?>;
        const languageCtx = document.getElementById('languageChart').getContext('2d');
        new Chart(languageCtx, {
            type: 'doughnut',
            data: {
                labels: languageData.map(item => item.preferred_language),
                datasets: [{
                    data: languageData.map(item => item.count),
                    backgroundColor: [
                        '#FF6384',
                        '#36A2EB',
                        '#FFCE56',
                        '#4BC0C0',
                        '#9966FF',
                        '#FF9F40'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>
