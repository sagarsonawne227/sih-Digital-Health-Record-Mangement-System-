<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Get system statistics
try {
    // User statistics
    $stmt = $pdo->query("SELECT 
                        COUNT(*) as total_users,
                        SUM(CASE WHEN user_type = 'patient' THEN 1 ELSE 0 END) as total_patients,
                        SUM(CASE WHEN user_type = 'doctor' THEN 1 ELSE 0 END) as total_doctors,
                        SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_users
                        FROM users");
    $user_stats = $stmt->fetch();
    
    // Medical records statistics
    $stmt = $pdo->query("SELECT 
                        COUNT(*) as total_records,
                        COUNT(DISTINCT patient_id) as patients_with_records,
                        SUM(CASE WHEN visit_date >= CURDATE() - INTERVAL 30 DAY THEN 1 ELSE 0 END) as recent_records
                        FROM medical_records");
    $record_stats = $stmt->fetch();
    
    // Appointment statistics
    $stmt = $pdo->query("SELECT 
                        COUNT(*) as total_appointments,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_appointments,
                        SUM(CASE WHEN appointment_date = CURDATE() THEN 1 ELSE 0 END) as today_appointments
                        FROM appointments");
    $appointment_stats = $stmt->fetch();
    
    // Recent activity
    $stmt = $pdo->query("SELECT sl.*, u.first_name, u.last_name 
                        FROM system_logs sl 
                        LEFT JOIN users u ON sl.user_id = u.id 
                        ORDER BY sl.created_at DESC 
                        LIMIT 10");
    $recent_activity = $stmt->fetchAll();
    
    // Country statistics for migrant workers
    $stmt = $pdo->query("SELECT country_of_origin, COUNT(*) as count 
                        FROM patients 
                        WHERE country_of_origin IS NOT NULL AND country_of_origin != '' 
                        GROUP BY country_of_origin 
                        ORDER BY count DESC 
                        LIMIT 10");
    $country_stats = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $user_stats = $record_stats = $appointment_stats = [];
    $recent_activity = $country_stats = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>Admin Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-1"></i>User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-1"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="system_logs.php">
                            <i class="fas fa-list-alt me-1"></i>System Logs
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-shield me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="welcome-card bg-gradient-primary text-white p-4 rounded mb-4">
                    <h2><i class="fas fa-shield-alt me-2"></i>System Administration Dashboard</h2>
                    <p class="mb-0">Digital Health Record Management System for Migrant Workers</p>
                </div>
            </div>
        </div>

        <!-- System Statistics -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3><?php echo $user_stats['total_users'] ?? 0; ?></h3>
                                <p class="mb-0">Total Users</p>
                                <small><?php echo $user_stats['active_users'] ?? 0; ?> active</small>
                            </div>
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3><?php echo $user_stats['total_patients'] ?? 0; ?></h3>
                                <p class="mb-0">Patients</p>
                                <small><?php echo $record_stats['patients_with_records'] ?? 0; ?> with records</small>
                            </div>
                            <i class="fas fa-user-injured fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3><?php echo $user_stats['total_doctors'] ?? 0; ?></h3>
                                <p class="mb-0">Doctors</p>
                                <small>Healthcare providers</small>
                            </div>
                            <i class="fas fa-user-md fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3><?php echo $record_stats['total_records'] ?? 0; ?></h3>
                                <p class="mb-0">Medical Records</p>
                                <small><?php echo $record_stats['recent_records'] ?? 0; ?> this month</small>
                            </div>
                            <i class="fas fa-file-medical fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Appointment Statistics -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card bg-secondary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3><?php echo $appointment_stats['total_appointments'] ?? 0; ?></h3>
                                <p class="mb-0">Total Appointments</p>
                            </div>
                            <i class="fas fa-calendar-check fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3><?php echo $appointment_stats['pending_appointments'] ?? 0; ?></h3>
                                <p class="mb-0">Pending Appointments</p>
                            </div>
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-dark text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h3><?php echo $appointment_stats['today_appointments'] ?? 0; ?></h3>
                                <p class="mb-0">Today's Appointments</p>
                            </div>
                            <i class="fas fa-calendar-day fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Recent Activity -->
            <div class="col-md-8 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-history me-2"></i>Recent System Activity</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recent_activity)): ?>
                        <p class="text-muted text-center py-3">No recent activity</p>
                        <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($recent_activity as $activity): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-start">
                                <div>
                                    <strong><?php echo htmlspecialchars($activity['action']); ?></strong>
                                    <?php if ($activity['first_name']): ?>
                                    <br><small class="text-muted">by <?php echo htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']); ?></small>
                                    <?php endif; ?>
                                    <?php if ($activity['table_name']): ?>
                                    <br><small class="text-muted">Table: <?php echo htmlspecialchars($activity['table_name']); ?></small>
                                    <?php endif; ?>
                                </div>
                                <small class="text-muted"><?php echo date('M d, H:i', strtotime($activity['created_at'])); ?></small>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="text-center mt-3">
                            <a href="system_logs.php" class="btn btn-outline-primary">View All Logs</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Migrant Worker Statistics -->
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-globe me-2"></i>Countries of Origin</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($country_stats)): ?>
                        <p class="text-muted text-center py-3">No country data available</p>
                        <?php else: ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($country_stats as $country): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <span><?php echo htmlspecialchars($country['country_of_origin']); ?></span>
                                <span class="badge bg-primary rounded-pill"><?php echo $country['count']; ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-tools me-2"></i>Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <a href="users.php" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-users fa-2x d-block mb-2"></i>
                                    Manage Users
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="reports.php" class="btn btn-outline-success w-100">
                                    <i class="fas fa-chart-bar fa-2x d-block mb-2"></i>
                                    Generate Reports
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="system_logs.php" class="btn btn-outline-info w-100">
                                    <i class="fas fa-list-alt fa-2x d-block mb-2"></i>
                                    System Logs
                                </a>
                            </div>
                            <div class="col-md-3 mb-3">
                                <a href="../install_check.php" class="btn btn-outline-warning w-100">
                                    <i class="fas fa-cog fa-2x d-block mb-2"></i>
                                    System Check
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
