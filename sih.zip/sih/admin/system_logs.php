<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Get filters
$page = (int)($_GET['page'] ?? 1);
$per_page = 50;
$offset = ($page - 1) * $per_page;

$action_filter = $_GET['action'] ?? '';
$user_filter = $_GET['user_id'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

$where_conditions = [];
$params = [];

if ($action_filter) {
    $where_conditions[] = "sl.action LIKE ?";
    $params[] = "%$action_filter%";
}

if ($user_filter) {
    $where_conditions[] = "sl.user_id = ?";
    $params[] = $user_filter;
}

if ($date_from) {
    $where_conditions[] = "DATE(sl.created_at) >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "DATE(sl.created_at) <= ?";
    $params[] = $date_to;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

try {
    // Get total count
    $count_sql = "SELECT COUNT(*) FROM system_logs sl $where_clause";
    $stmt = $pdo->prepare($count_sql);
    $stmt->execute($params);
    $total_logs = $stmt->fetchColumn();
    
    // Get logs
    $sql = "SELECT sl.*, u.username, u.first_name, u.last_name, u.user_type
            FROM system_logs sl 
            LEFT JOIN users u ON sl.user_id = u.id 
            $where_clause 
            ORDER BY sl.created_at DESC 
            LIMIT $per_page OFFSET $offset";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();
    
    $total_pages = ceil($total_logs / $per_page);
    
    // Get unique actions for filter
    $stmt = $pdo->query("SELECT DISTINCT action FROM system_logs ORDER BY action");
    $actions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get users for filter
    $stmt = $pdo->query("SELECT DISTINCT u.id, u.username, u.first_name, u.last_name 
                        FROM users u 
                        INNER JOIN system_logs sl ON u.id = sl.user_id 
                        ORDER BY u.username");
    $users = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $logs = [];
    $total_logs = 0;
    $total_pages = 0;
    $actions = [];
    $users = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Logs - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>Admin Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-1"></i>User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-1"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="system_logs.php">
                            <i class="fas fa-list-alt me-1"></i>System Logs
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-shield me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4><i class="fas fa-list-alt me-2"></i>System Activity Logs</h4>
                        <span class="badge bg-primary"><?php echo number_format($total_logs); ?> Total Entries</span>
                    </div>
                    <div class="card-body">
                        <!-- Filters -->
                        <form method="GET" class="mb-4">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label">Action</label>
                                    <select class="form-select" name="action">
                                        <option value="">All Actions</option>
                                        <?php foreach ($actions as $action): ?>
                                        <option value="<?php echo htmlspecialchars($action); ?>" 
                                                <?php echo $action_filter === $action ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($action); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">User</label>
                                    <select class="form-select" name="user_id">
                                        <option value="">All Users</option>
                                        <?php foreach ($users as $user): ?>
                                        <option value="<?php echo $user['id']; ?>" 
                                                <?php echo $user_filter == $user['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($user['username'] . ' (' . $user['first_name'] . ' ' . $user['last_name'] . ')'); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">From Date</label>
                                    <input type="date" class="form-control" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">To Date</label>
                                    <input type="date" class="form-control" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">&nbsp;</label>
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-filter me-1"></i>Filter
                                        </button>
                                        <a href="system_logs.php" class="btn btn-outline-secondary">
                                            <i class="fas fa-times me-1"></i>Clear
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <!-- Logs Table -->
                        <div class="table-responsive">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Timestamp</th>
                                        <th>User</th>
                                        <th>Action</th>
                                        <th>Table</th>
                                        <th>Record ID</th>
                                        <th>Details</th>
                                        <th>IP Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($logs)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">No logs found</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td>
                                            <small><?php echo date('M d, Y H:i:s', strtotime($log['created_at'])); ?></small>
                                        </td>
                                        <td>
                                            <?php if ($log['username']): ?>
                                            <div>
                                                <strong><?php echo htmlspecialchars($log['username']); ?></strong>
                                                <br><small class="text-muted">
                                                    <?php echo htmlspecialchars($log['first_name'] . ' ' . $log['last_name']); ?>
                                                    <span class="badge badge-sm bg-<?php 
                                                        echo $log['user_type'] === 'admin' ? 'danger' : 
                                                            ($log['user_type'] === 'doctor' ? 'success' : 'info'); 
                                                    ?>"><?php echo ucfirst($log['user_type']); ?></span>
                                                </small>
                                            </div>
                                            <?php else: ?>
                                            <span class="text-muted">System</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                $action_colors = [
                                                    'login' => 'success',
                                                    'logout' => 'secondary',
                                                    'create' => 'primary',
                                                    'update' => 'warning',
                                                    'delete' => 'danger',
                                                    'view' => 'info'
                                                ];
                                                $color = 'secondary';
                                                foreach ($action_colors as $key => $value) {
                                                    if (stripos($log['action'], $key) !== false) {
                                                        $color = $value;
                                                        break;
                                                    }
                                                }
                                                echo $color;
                                            ?>">
                                                <?php echo htmlspecialchars($log['action']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($log['table_name']): ?>
                                            <code><?php echo htmlspecialchars($log['table_name']); ?></code>
                                            <?php else: ?>
                                            <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($log['record_id']): ?>
                                            <code><?php echo htmlspecialchars($log['record_id']); ?></code>
                                            <?php else: ?>
                                            <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($log['details']): ?>
                                            <small><?php echo htmlspecialchars($log['details']); ?></small>
                                            <?php else: ?>
                                            <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($log['ip_address']): ?>
                                            <small><code><?php echo htmlspecialchars($log['ip_address']); ?></code></small>
                                            <?php else: ?>
                                            <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                        <nav aria-label="Logs pagination">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&action=<?php echo urlencode($action_filter); ?>&user_id=<?php echo urlencode($user_filter); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>">Previous</a>
                                </li>
                                <?php endif; ?>
                                
                                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&action=<?php echo urlencode($action_filter); ?>&user_id=<?php echo urlencode($user_filter); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>"><?php echo $i; ?></a>
                                </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&action=<?php echo urlencode($action_filter); ?>&user_id=<?php echo urlencode($user_filter); ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>">Next</a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>

                        <!-- Log Statistics -->
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="alert alert-info">
                                    <h6><i class="fas fa-info-circle me-2"></i>Log Information</h6>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <strong>Total Entries:</strong> <?php echo number_format($total_logs); ?>
                                        </div>
                                        <div class="col-md-3">
                                            <strong>Current Page:</strong> <?php echo $page; ?> of <?php echo $total_pages; ?>
                                        </div>
                                        <div class="col-md-3">
                                            <strong>Per Page:</strong> <?php echo $per_page; ?>
                                        </div>
                                        <div class="col-md-3">
                                            <strong>Date Range:</strong> 
                                            <?php if ($date_from || $date_to): ?>
                                                <?php echo $date_from ?: 'Start'; ?> to <?php echo $date_to ?: 'End'; ?>
                                            <?php else: ?>
                                                All Time
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
