<?php
session_start();
require_once '../config/database.php';
require_once '../config/security.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Handle user actions
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'toggle_status':
            $user_id = (int)$_POST['user_id'];
            $new_status = $_POST['new_status'] === '1' ? 1 : 0;
            
            try {
                $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
                $stmt->execute([$new_status, $user_id]);
                
                // Log the action
                logAuditEvent($pdo, $_SESSION['user_id'], 'user_status_change', 'users', $user_id, 
                             "User status changed to " . ($new_status ? 'active' : 'inactive'));
                
                $success_message = "User status updated successfully.";
            } catch (PDOException $e) {
                $error_message = "Failed to update user status.";
            }
            break;
            
        case 'reset_password':
            $user_id = (int)$_POST['user_id'];
            $new_password = generateSecurePassword();
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            try {
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->execute([$hashed_password, $user_id]);
                
                // Log the action
                logAuditEvent($pdo, $_SESSION['user_id'], 'password_reset', 'users', $user_id, 
                             "Password reset by administrator");
                
                $success_message = "Password reset successfully. New password: " . $new_password;
            } catch (PDOException $e) {
                $error_message = "Failed to reset password.";
            }
            break;
            
        case 'delete_user':
            $user_id = (int)$_POST['user_id'];
            
            try {
                $pdo->beginTransaction();
                
                // Get user info before deletion
                $stmt = $pdo->prepare("SELECT username, user_type FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                $user_info = $stmt->fetch();
                
                // Delete related records based on user type
                if ($user_info['user_type'] === 'patient') {
                    // Delete patient-related records
                    $stmt = $pdo->prepare("DELETE FROM appointments WHERE patient_id IN (SELECT id FROM patients WHERE user_id = ?)");
                    $stmt->execute([$user_id]);
                    
                    $stmt = $pdo->prepare("DELETE FROM medical_records WHERE patient_id IN (SELECT id FROM patients WHERE user_id = ?)");
                    $stmt->execute([$user_id]);
                    
                    $stmt = $pdo->prepare("DELETE FROM patients WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                } elseif ($user_info['user_type'] === 'doctor') {
                    // Update records to remove doctor reference
                    $stmt = $pdo->prepare("UPDATE medical_records SET doctor_id = NULL WHERE doctor_id IN (SELECT id FROM doctors WHERE user_id = ?)");
                    $stmt->execute([$user_id]);
                    
                    $stmt = $pdo->prepare("UPDATE appointments SET doctor_id = NULL WHERE doctor_id IN (SELECT id FROM doctors WHERE user_id = ?)");
                    $stmt->execute([$user_id]);
                    
                    $stmt = $pdo->prepare("DELETE FROM doctors WHERE user_id = ?");
                    $stmt->execute([$user_id]);
                }
                
                // Delete the user
                $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                $stmt->execute([$user_id]);
                
                $pdo->commit();
                
                // Log the action
                logAuditEvent($pdo, $_SESSION['user_id'], 'user_deleted', 'users', $user_id, 
                             "User deleted: " . $user_info['username']);
                
                $success_message = "User deleted successfully.";
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error_message = "Failed to delete user: " . $e->getMessage();
            }
            break;
    }
}

// Get users with pagination
$page = (int)($_GET['page'] ?? 1);
$per_page = 20;
$offset = ($page - 1) * $per_page;

$search = $_GET['search'] ?? '';
$user_type_filter = $_GET['user_type'] ?? '';
$status_filter = $_GET['status'] ?? '';

$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "(u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
}

if ($user_type_filter) {
    $where_conditions[] = "u.user_type = ?";
    $params[] = $user_type_filter;
}

if ($status_filter !== '') {
    $where_conditions[] = "u.is_active = ?";
    $params[] = $status_filter;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

try {
    // Get total count
    $count_sql = "SELECT COUNT(*) FROM users u $where_clause";
    $stmt = $pdo->prepare($count_sql);
    $stmt->execute($params);
    $total_users = $stmt->fetchColumn();
    
    // Get users
    $sql = "SELECT u.*, 
            CASE 
                WHEN u.user_type = 'patient' THEN p.patient_id
                WHEN u.user_type = 'doctor' THEN d.license_number
                ELSE NULL
            END as identifier
            FROM users u 
            LEFT JOIN patients p ON u.id = p.user_id AND u.user_type = 'patient'
            LEFT JOIN doctors d ON u.id = d.user_id AND u.user_type = 'doctor'
            $where_clause 
            ORDER BY u.created_at DESC 
            LIMIT $per_page OFFSET $offset";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
    
    $total_pages = ceil($total_users / $per_page);
    
} catch (PDOException $e) {
    $users = [];
    $total_users = 0;
    $total_pages = 0;
}

function generateSecurePassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    return substr(str_shuffle($chars), 0, $length);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-1"></i>Admin Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="users.php">
                            <i class="fas fa-users me-1"></i>User Management
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-1"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="system_logs.php">
                            <i class="fas fa-list-alt me-1"></i>System Logs
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-shield me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($success_message)): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success_message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error_message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4><i class="fas fa-users me-2"></i>User Management</h4>
                        <span class="badge bg-primary"><?php echo $total_users; ?> Total Users</span>
                    </div>
                    <div class="card-body">
                        <!-- Search and Filters -->
                        <form method="GET" class="mb-4">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <input type="text" class="form-control" name="search" placeholder="Search users..." 
                                           value="<?php echo htmlspecialchars($search); ?>">
                                </div>
                                <div class="col-md-2 mb-3">
                                    <select class="form-select" name="user_type">
                                        <option value="">All Types</option>
                                        <option value="patient" <?php echo $user_type_filter === 'patient' ? 'selected' : ''; ?>>Patients</option>
                                        <option value="doctor" <?php echo $user_type_filter === 'doctor' ? 'selected' : ''; ?>>Doctors</option>
                                        <option value="admin" <?php echo $user_type_filter === 'admin' ? 'selected' : ''; ?>>Admins</option>
                                    </select>
                                </div>
                                <div class="col-md-2 mb-3">
                                    <select class="form-select" name="status">
                                        <option value="">All Status</option>
                                        <option value="1" <?php echo $status_filter === '1' ? 'selected' : ''; ?>>Active</option>
                                        <option value="0" <?php echo $status_filter === '0' ? 'selected' : ''; ?>>Inactive</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search me-1"></i>Search
                                    </button>
                                    <a href="users.php" class="btn btn-outline-secondary">
                                        <i class="fas fa-times me-1"></i>Clear
                                    </a>
                                </div>
                            </div>
                        </form>

                        <!-- Users Table -->
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Type</th>
                                        <th>Identifier</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($users)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted py-4">No users found</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo $user['id']; ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $user['user_type'] === 'admin' ? 'danger' : 
                                                    ($user['user_type'] === 'doctor' ? 'success' : 'info'); 
                                            ?>">
                                                <?php echo ucfirst($user['user_type']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($user['identifier'] ?? '-'); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $user['is_active'] ? 'success' : 'secondary'; ?>">
                                                <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <!-- Toggle Status -->
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="toggle_status">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <input type="hidden" name="new_status" value="<?php echo $user['is_active'] ? '0' : '1'; ?>">
                                                    <button type="submit" class="btn btn-outline-<?php echo $user['is_active'] ? 'warning' : 'success'; ?>" 
                                                            onclick="return confirm('Are you sure you want to <?php echo $user['is_active'] ? 'deactivate' : 'activate'; ?> this user?')">
                                                        <i class="fas fa-<?php echo $user['is_active'] ? 'pause' : 'play'; ?>"></i>
                                                    </button>
                                                </form>
                                                
                                                <!-- Reset Password -->
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="reset_password">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" class="btn btn-outline-info" 
                                                            onclick="return confirm('Are you sure you want to reset this user\'s password?')">
                                                        <i class="fas fa-key"></i>
                                                    </button>
                                                </form>
                                                
                                                <!-- Delete User -->
                                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="delete_user">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" class="btn btn-outline-danger" 
                                                            onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone and will delete all associated data.')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                        <nav aria-label="Users pagination">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&user_type=<?php echo urlencode($user_type_filter); ?>&status=<?php echo urlencode($status_filter); ?>">Previous</a>
                                </li>
                                <?php endif; ?>
                                
                                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&user_type=<?php echo urlencode($user_type_filter); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                                </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&user_type=<?php echo urlencode($user_type_filter); ?>&status=<?php echo urlencode($status_filter); ?>">Next</a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
