<?php
session_start();
require_once 'config/database.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: auth/login.php');
    exit();
}

// Get user info
$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];
$user_name = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Health Records - Migrant Workers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-heartbeat me-2"></i>
                Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <?php if ($user_type === 'patient'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="patient/profile.php">
                            <i class="fas fa-user me-1"></i>My Profile
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="patient/records.php">
                            <i class="fas fa-file-medical me-1"></i>My Records
                        </a>
                    </li>
                    <?php elseif ($user_type === 'doctor'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="doctor/patients.php">
                            <i class="fas fa-users me-1"></i>Patients
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="doctor/records.php">
                            <i class="fas fa-clipboard-list me-1"></i>Records
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($user_name); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="welcome-card bg-gradient-primary text-white p-4 rounded mb-4">
                    <h2><i class="fas fa-hand-holding-heart me-2"></i>WELCOME <?php echo htmlspecialchars($user_name); ?>!</h2>
                    <p class="mb-0">Digital Health Record Management System for Migrant Workers</p>
                </div>
            </div>
        </div>

        <?php if ($user_type === 'patient'): ?>
        <!-- Patient Dashboard -->
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-user-circle fa-3x text-primary mb-3"></i>
                        <h5 class="card-title">My Profile</h5>
                        <p class="card-text">View and update your personal information</p>
                        <a href="patient/profile.php" class="btn btn-primary">View Profile</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-file-medical-alt fa-3x text-success mb-3"></i>
                        <h5 class="card-title">Health Records</h5>
                        <p class="card-text">Access your medical history and records</p>
                        <a href="patient/records.php" class="btn btn-success">View Records</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar-check fa-3x text-info mb-3"></i>
                        <h5 class="card-title">Appointments</h5>
                        <p class="card-text">Schedule and manage appointments</p>
                        <a href="patient/appointments.php" class="btn btn-info">Appointments</a>
                    </div>
                </div>
            </div>
        </div>

        <?php elseif ($user_type === 'doctor'): ?>
        <!-- Doctor Dashboard -->
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4>
                                    <?php
                                    $stmt = $pdo->query("SELECT COUNT(*) FROM patients");
                                    echo $stmt->fetchColumn();
                                    ?>
                                </h4>
                                <p>Total Patients</p>
                            </div>
                            <i class="fas fa-users fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4>
                                    <?php
                                    $stmt = $pdo->query("SELECT COUNT(*) FROM medical_records");
                                    echo $stmt->fetchColumn();
                                    ?>
                                </h4>
                                <p>Total Records</p>
                            </div>
                            <i class="fas fa-file-medical fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4>
                                    <?php
                                    $stmt = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = CURDATE()");
                                    echo $stmt->fetchColumn();
                                    ?>
                                </h4>
                                <p>Today's Appointments</p>
                            </div>
                            <i class="fas fa-calendar-day fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4>
                                    <?php
                                    $stmt = $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'pending'");
                                    echo $stmt->fetchColumn();
                                    ?>
                                </h4>
                                <p>Pending Appointments</p>
                            </div>
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-users me-2"></i>Recent Patients</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $stmt = $pdo->query("SELECT * FROM patients ORDER BY created_at DESC LIMIT 5");
                        $recent_patients = $stmt->fetchAll();
                        ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($recent_patients as $patient): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></strong><br>
                                    <small class="text-muted">ID: <?php echo $patient['patient_id']; ?></small>
                                </div>
                                <a href="doctor/patient_details.php?id=<?php echo $patient['id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="text-center mt-3">
                            <a href="doctor/patients.php" class="btn btn-primary">View All Patients</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-calendar me-2"></i>Today's Appointments</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $stmt = $pdo->prepare("SELECT a.*, p.first_name, p.last_name FROM appointments a 
                                             JOIN patients p ON a.patient_id = p.id 
                                             WHERE a.appointment_date = CURDATE() 
                                             ORDER BY a.appointment_time");
                        $stmt->execute();
                        $today_appointments = $stmt->fetchAll();
                        ?>
                        <div class="list-group list-group-flush">
                            <?php if (empty($today_appointments)): ?>
                            <div class="text-center text-muted py-3">
                                <i class="fas fa-calendar-times fa-2x mb-2"></i>
                                <p>No appointments today</p>
                            </div>
                            <?php else: ?>
                            <?php foreach ($today_appointments as $appointment): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?></strong><br>
                                    <small class="text-muted"><?php echo date('g:i A', strtotime($appointment['appointment_time'])); ?></small>
                                </div>
                                <span class="badge bg-<?php echo $appointment['status'] === 'confirmed' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($appointment['status']); ?>
                                </span>
                            </div>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
