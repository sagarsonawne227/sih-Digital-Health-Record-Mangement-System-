<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: auth/login.php');
    exit();
}

$user_type = $_SESSION['user_type'];
$user_id = $_SESSION['user_id'];

// Handle export request
if ($_POST && isset($_POST['export_type'])) {
    $export_type = $_POST['export_type'];
    $format = $_POST['format'] ?? 'csv';
    
    // Set headers for download
    $filename = $export_type . '_' . date('Y-m-d_H-i-s') . '.' . $format;
    
    if ($format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $output = fopen('php://output', 'w');
    } else {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
    }
    
    try {
        switch ($export_type) {
            case 'patients':
                if ($user_type !== 'doctor' && $user_type !== 'admin') {
                    die('Access denied');
                }
                
                $stmt = $pdo->query("SELECT patient_id, first_name, last_name, date_of_birth, gender, phone, email, country_of_origin, current_location, preferred_language, created_at FROM patients ORDER BY created_at DESC");
                $data = $stmt->fetchAll();
                
                if ($format === 'csv') {
                    fputcsv($output, ['Patient ID', 'First Name', 'Last Name', 'Date of Birth', 'Gender', 'Phone', 'Email', 'Country of Origin', 'Current Location', 'Preferred Language', 'Registration Date']);
                    foreach ($data as $row) {
                        fputcsv($output, $row);
                    }
                    fclose($output);
                } else {
                    echo json_encode($data, JSON_PRETTY_PRINT);
                }
                break;
                
            case 'medical_records':
                if ($user_type === 'patient') {
                    // Patient can only export their own records
                    $stmt = $pdo->prepare("SELECT p.id FROM patients p WHERE p.user_id = ?");
                    $stmt->execute([$user_id]);
                    $patient = $stmt->fetch();
                    
                    if (!$patient) {
                        die('Access denied');
                    }
                    
                    $stmt = $pdo->prepare("SELECT mr.*, p.patient_id, p.first_name, p.last_name, d.first_name as doctor_first_name, d.last_name as doctor_last_name 
                                          FROM medical_records mr 
                                          JOIN patients p ON mr.patient_id = p.id 
                                          LEFT JOIN doctors d ON mr.doctor_id = d.id 
                                          WHERE mr.patient_id = ? 
                                          ORDER BY mr.visit_date DESC");
                    $stmt->execute([$patient['id']]);
                } else {
                    // Doctor/Admin can export all records
                    $stmt = $pdo->query("SELECT mr.*, p.patient_id, p.first_name, p.last_name, d.first_name as doctor_first_name, d.last_name as doctor_last_name 
                                        FROM medical_records mr 
                                        JOIN patients p ON mr.patient_id = p.id 
                                        LEFT JOIN doctors d ON mr.doctor_id = d.id 
                                        ORDER BY mr.visit_date DESC");
                }
                
                $data = $stmt->fetchAll();
                
                if ($format === 'csv') {
                    fputcsv($output, ['Patient ID', 'Patient Name', 'Doctor', 'Record Type', 'Visit Date', 'Chief Complaint', 'Diagnosis', 'Treatment Plan', 'Blood Pressure', 'Heart Rate', 'Temperature', 'Weight', 'Height']);
                    foreach ($data as $row) {
                        fputcsv($output, [
                            $row['patient_id'],
                            $row['first_name'] . ' ' . $row['last_name'],
                            ($row['doctor_first_name'] ? 'Dr. ' . $row['doctor_first_name'] . ' ' . $row['doctor_last_name'] : ''),
                            $row['record_type'],
                            $row['visit_date'],
                            $row['chief_complaint'],
                            $row['diagnosis'],
                            $row['treatment_plan'],
                            $row['blood_pressure'],
                            $row['heart_rate'],
                            $row['temperature'],
                            $row['weight'],
                            $row['height']
                        ]);
                    }
                    fclose($output);
                } else {
                    echo json_encode($data, JSON_PRETTY_PRINT);
                }
                break;
                
            case 'appointments':
                if ($user_type === 'patient') {
                    // Patient can only export their own appointments
                    $stmt = $pdo->prepare("SELECT p.id FROM patients p WHERE p.user_id = ?");
                    $stmt->execute([$user_id]);
                    $patient = $stmt->fetch();
                    
                    if (!$patient) {
                        die('Access denied');
                    }
                    
                    $stmt = $pdo->prepare("SELECT a.*, p.patient_id, p.first_name, p.last_name, d.first_name as doctor_first_name, d.last_name as doctor_last_name 
                                          FROM appointments a 
                                          JOIN patients p ON a.patient_id = p.id 
                                          LEFT JOIN doctors d ON a.doctor_id = d.id 
                                          WHERE a.patient_id = ? 
                                          ORDER BY a.appointment_date DESC");
                    $stmt->execute([$patient['id']]);
                } else {
                    // Doctor/Admin can export all appointments
                    $stmt = $pdo->query("SELECT a.*, p.patient_id, p.first_name, p.last_name, d.first_name as doctor_first_name, d.last_name as doctor_last_name 
                                        FROM appointments a 
                                        JOIN patients p ON a.patient_id = p.id 
                                        LEFT JOIN doctors d ON a.doctor_id = d.id 
                                        ORDER BY a.appointment_date DESC");
                }
                
                $data = $stmt->fetchAll();
                
                if ($format === 'csv') {
                    fputcsv($output, ['Patient ID', 'Patient Name', 'Doctor', 'Appointment Date', 'Appointment Time', 'Type', 'Status', 'Reason']);
                    foreach ($data as $row) {
                        fputcsv($output, [
                            $row['patient_id'],
                            $row['first_name'] . ' ' . $row['last_name'],
                            ($row['doctor_first_name'] ? 'Dr. ' . $row['doctor_first_name'] . ' ' . $row['doctor_last_name'] : ''),
                            $row['appointment_date'],
                            $row['appointment_time'],
                            $row['appointment_type'],
                            $row['status'],
                            $row['reason']
                        ]);
                    }
                    fclose($output);
                } else {
                    echo json_encode($data, JSON_PRETTY_PRINT);
                }
                break;
                
            default:
                die('Invalid export type');
        }
        
    } catch (PDOException $e) {
        die('Export failed: ' . $e->getMessage());
    }
    
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Data - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-download me-2"></i>Export Data</h4>
                        <p class="mb-0 text-muted">Export your health records and data</p>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>Data Privacy Notice:</strong> Exported data contains sensitive medical information. 
                            Please ensure you handle and store this data securely according to applicable privacy regulations.
                        </div>

                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Data Type</label>
                                    <select class="form-select" name="export_type" required>
                                        <option value="">Select data to export</option>
                                        <?php if ($user_type === 'patient'): ?>
                                        <option value="medical_records">My Medical Records</option>
                                        <option value="appointments">My Appointments</option>
                                        <?php else: ?>
                                        <option value="patients">Patient List</option>
                                        <option value="medical_records">Medical Records</option>
                                        <option value="appointments">Appointments</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Format</label>
                                    <select class="form-select" name="format" required>
                                        <option value="csv">CSV (Excel Compatible)</option>
                                        <option value="json">JSON (Developer Format)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="privacy_agreement" required>
                                    <label class="form-check-label" for="privacy_agreement">
                                        I understand that this export contains sensitive medical data and I will handle it responsibly
                                    </label>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-download me-2"></i>Export Data
                                </button>
                                <a href="index.php" class="btn btn-secondary btn-lg ms-2">
                                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Export Information -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5><i class="fas fa-info-circle me-2"></i>Export Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>CSV Format</h6>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-check text-success me-2"></i>Excel compatible</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Easy to read and analyze</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Suitable for reports</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h6>JSON Format</h6>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-check text-success me-2"></i>Machine readable</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Preserves data structure</li>
                                    <li><i class="fas fa-check text-success me-2"></i>Developer friendly</li>
                                </ul>
                            </div>
                        </div>

                        <div class="alert alert-warning mt-3">
                            <strong>Security Reminder:</strong>
                            <ul class="mb-0 mt-2">
                                <li>Do not share exported files via unsecured channels</li>
                                <li>Store files in encrypted locations</li>
                                <li>Delete files when no longer needed</li>
                                <li>Comply with local data protection regulations</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
