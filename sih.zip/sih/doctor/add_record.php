<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'doctor') {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$patient_id = $_GET['patient_id'] ?? '';

// Get doctor information
try {
    $stmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: ../auth/login.php');
        exit();
    }
    
    $doctor_id = $doctor['id'];
} catch (PDOException $e) {
    die('Error loading doctor information.');
}

// Get patient information
$patient = null;
if ($patient_id) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
        $stmt->execute([$patient_id]);
        $patient = $stmt->fetch();
    } catch (PDOException $e) {
        $patient = null;
    }
}

$error = '';
$success = '';

if ($_POST) {
    $selected_patient_id = $_POST['patient_id'];
    $record_type = $_POST['record_type'];
    $visit_date = $_POST['visit_date'];
    $visit_time = $_POST['visit_time'];
    $chief_complaint = trim($_POST['chief_complaint']);
    $symptoms = trim($_POST['symptoms']);
    $diagnosis = trim($_POST['diagnosis']);
    $treatment_plan = trim($_POST['treatment_plan']);
    $medications = trim($_POST['medications']);
    $notes = trim($_POST['notes']);
    
    // Vital signs
    $blood_pressure = trim($_POST['blood_pressure']);
    $heart_rate = $_POST['heart_rate'] ? (int)$_POST['heart_rate'] : null;
    $temperature = $_POST['temperature'] ? (float)$_POST['temperature'] : null;
    $weight = $_POST['weight'] ? (float)$_POST['weight'] : null;
    $height = $_POST['height'] ? (float)$_POST['height'] : null;
    
    // Follow-up
    $follow_up_required = isset($_POST['follow_up_required']) ? 1 : 0;
    $follow_up_date = $_POST['follow_up_date'] ?: null;
    $follow_up_notes = trim($_POST['follow_up_notes']);
    
    // Validation
    if (empty($selected_patient_id) || empty($record_type) || empty($visit_date)) {
        $error = 'Patient, record type, and visit date are required.';
    } else {
        try {
            $pdo->beginTransaction();
            
            // Insert medical record
            $stmt = $pdo->prepare("INSERT INTO medical_records (patient_id, doctor_id, record_type, visit_date, visit_time, chief_complaint, symptoms, diagnosis, treatment_plan, medications, notes, blood_pressure, heart_rate, temperature, weight, height, follow_up_required, follow_up_date, follow_up_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$selected_patient_id, $doctor_id, $record_type, $visit_date, $visit_time, $chief_complaint, $symptoms, $diagnosis, $treatment_plan, $medications, $notes, $blood_pressure, $heart_rate, $temperature, $weight, $height, $follow_up_required, $follow_up_date, $follow_up_notes]);
            
            $record_id = $pdo->lastInsertId();
            
            // Add prescriptions if medications are specified
            if ($medications) {
                $medication_lines = explode("\n", $medications);
                foreach ($medication_lines as $med_line) {
                    $med_line = trim($med_line);
                    if ($med_line) {
                        $stmt = $pdo->prepare("INSERT INTO prescriptions (medical_record_id, patient_id, doctor_id, medication_name, prescribed_date, status) VALUES (?, ?, ?, ?, ?, 'active')");
                        $stmt->execute([$record_id, $selected_patient_id, $doctor_id, $med_line, $visit_date]);
                    }
                }
            }
            
            $pdo->commit();
            $success = 'Medical record added successfully!';
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Error adding medical record. Please try again.';
        }
    }
}

// Get all patients for dropdown
try {
    $stmt = $pdo->query("SELECT id, patient_id, first_name, last_name FROM patients ORDER BY first_name, last_name");
    $all_patients = $stmt->fetchAll();
} catch (PDOException $e) {
    $all_patients = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Medical Record - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="patients.php">
                            <i class="fas fa-users me-1"></i>Patients
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="records.php">
                            <i class="fas fa-clipboard-list me-1"></i>Records
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-file-medical-alt me-2"></i>Add Medical Record</h2>
                    <a href="patients.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Patients
                    </a>
                </div>
            </div>
        </div>

        <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="row">
                <!-- Patient and Visit Information -->
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-user me-2"></i>Patient & Visit Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Patient *</label>
                                <select class="form-select" name="patient_id" required>
                                    <option value="">Select Patient</option>
                                    <?php foreach ($all_patients as $p): ?>
                                    <option value="<?php echo $p['id']; ?>" <?php echo ($patient && $p['id'] == $patient['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($p['first_name'] . ' ' . $p['last_name'] . ' (' . $p['patient_id'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Record Type *</label>
                                    <select class="form-select" name="record_type" required>
                                        <option value="">Select Type</option>
                                        <option value="consultation">Consultation</option>
                                        <option value="diagnosis">Diagnosis</option>
                                        <option value="prescription">Prescription</option>
                                        <option value="lab_result">Lab Result</option>
                                        <option value="vaccination">Vaccination</option>
                                        <option value="emergency">Emergency</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Visit Date *</label>
                                    <input type="date" class="form-control" name="visit_date" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Visit Time</label>
                                <input type="time" class="form-control" name="visit_time" value="<?php echo date('H:i'); ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Vital Signs -->
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-heartbeat me-2"></i>Vital Signs</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Blood Pressure</label>
                                    <input type="text" class="form-control" name="blood_pressure" placeholder="120/80">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Heart Rate (bpm)</label>
                                    <input type="number" class="form-control" name="heart_rate" placeholder="72">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Temperature (°F)</label>
                                    <input type="number" step="0.1" class="form-control" name="temperature" placeholder="98.6">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Weight (kg)</label>
                                    <input type="number" step="0.1" class="form-control" name="weight" placeholder="70.0">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Height (cm)</label>
                                    <input type="number" step="0.1" class="form-control" name="height" placeholder="175.0">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Medical Information -->
                <div class="col-md-8 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-clipboard-list me-2"></i>Medical Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Chief Complaint</label>
                                <textarea class="form-control" name="chief_complaint" rows="2" placeholder="Patient's main concern or reason for visit"></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Symptoms</label>
                                <textarea class="form-control" name="symptoms" rows="3" placeholder="Describe symptoms observed or reported"></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Diagnosis</label>
                                <textarea class="form-control" name="diagnosis" rows="2" placeholder="Medical diagnosis or assessment"></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Treatment Plan</label>
                                <textarea class="form-control" name="treatment_plan" rows="3" placeholder="Recommended treatment and care plan"></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Medications</label>
                                <textarea class="form-control" name="medications" rows="3" placeholder="Prescribed medications (one per line)"></textarea>
                                <small class="text-muted">Enter each medication on a separate line</small>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Additional Notes</label>
                                <textarea class="form-control" name="notes" rows="3" placeholder="Any additional notes or observations"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Follow-up -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-calendar-check me-2"></i>Follow-up</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="follow_up_required" id="follow_up_required">
                                    <label class="form-check-label" for="follow_up_required">
                                        Follow-up Required
                                    </label>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Follow-up Date</label>
                                <input type="date" class="form-control" name="follow_up_date">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Follow-up Notes</label>
                                <textarea class="form-control" name="follow_up_notes" rows="3" placeholder="Notes for follow-up visit"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="text-center">
                        <button type="submit" class="btn btn-success btn-lg me-3">
                            <i class="fas fa-save me-2"></i>Save Medical Record
                        </button>
                        <a href="patients.php" class="btn btn-secondary btn-lg">
                            <i class="fas fa-times me-2"></i>Cancel
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
