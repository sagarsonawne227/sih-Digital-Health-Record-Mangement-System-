<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'doctor') {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get doctor information
try {
    $stmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: ../auth/login.php');
        exit();
    }
    
    $doctor_id = $doctor['id'];
} catch (PDOException $e) {
    die('Error loading doctor information.');
}

// Handle appointment status updates
if ($_POST && isset($_POST['update_status'])) {
    $appointment_id = $_POST['appointment_id'];
    $new_status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE appointments SET status = ? WHERE id = ? AND doctor_id = ?");
        $stmt->execute([$new_status, $appointment_id, $doctor_id]);
        $success = 'Appointment status updated successfully!';
    } catch (PDOException $e) {
        $error = 'Error updating appointment status.';
    }
}

// Get appointments with filters
$date_filter = $_GET['date'] ?? date('Y-m-d');
$status_filter = $_GET['status'] ?? '';

$where_conditions = ["a.doctor_id = ?"];
$params = [$doctor_id];

if ($date_filter) {
    $where_conditions[] = "a.appointment_date = ?";
    $params[] = $date_filter;
}

if ($status_filter) {
    $where_conditions[] = "a.status = ?";
    $params[] = $status_filter;
}

$where_clause = implode(' AND ', $where_conditions);

try {
    $stmt = $pdo->prepare("SELECT a.*, p.first_name, p.last_name, p.patient_id, p.phone, p.country_of_origin 
                          FROM appointments a 
                          JOIN patients p ON a.patient_id = p.id 
                          WHERE $where_clause
                          ORDER BY a.appointment_date, a.appointment_time");
    $stmt->execute($params);
    $appointments = $stmt->fetchAll();
} catch (PDOException $e) {
    $appointments = [];
}

// Get appointment statistics
try {
    $stmt = $pdo->prepare("SELECT 
                          COUNT(*) as total,
                          SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                          SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                          SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                          SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
                          FROM appointments WHERE doctor_id = ? AND appointment_date = ?");
    $stmt->execute([$doctor_id, $date_filter]);
    $stats = $stmt->fetch();
} catch (PDOException $e) {
    $stats = ['total' => 0, 'pending' => 0, 'confirmed' => 0, 'completed' => 0, 'cancelled' => 0];
}

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="patients.php">
                            <i class="fas fa-users me-1"></i>Patients
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="records.php">
                            <i class="fas fa-clipboard-list me-1"></i>Records
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="appointments.php">
                            <i class="fas fa-calendar-check me-1"></i>Appointments
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <h2><i class="fas fa-calendar-check me-2"></i>Appointment Management</h2>
                <p class="text-muted">Manage your patient appointments</p>
            </div>
        </div>

        <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-header">
                <h5><i class="fas fa-filter me-2"></i>Filters</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" class="form-control" name="date" value="<?php echo htmlspecialchars($date_filter); ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option value="">All Statuses</option>
                                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="confirmed" <?php echo $status_filter === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                <option value="completed" <?php echo $status_filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                <option value="no_show" <?php echo $status_filter === 'no_show' ? 'selected' : ''; ?>>No Show</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">&nbsp;</label>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search me-1"></i>Filter
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-md-2 mb-3">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center">
                        <h4><?php echo $stats['total']; ?></h4>
                        <small>Total</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <h4><?php echo $stats['pending']; ?></h4>
                        <small>Pending</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <h4><?php echo $stats['confirmed']; ?></h4>
                        <small>Confirmed</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <h4><?php echo $stats['completed']; ?></h4>
                        <small>Completed</small>
                    </div>
                </div>
            </div>
            <div class="col-md-2 mb-3">
                <div class="card bg-secondary text-white">
                    <div class="card-body text-center">
                        <h4><?php echo $stats['cancelled']; ?></h4>
                        <small>Cancelled</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Appointments List -->
        <?php if (empty($appointments)): ?>
        <div class="text-center py-5">
            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
            <h4>No Appointments Found</h4>
            <p class="text-muted">No appointments found for the selected date and filters.</p>
        </div>
        <?php else: ?>
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Time</th>
                                <th>Patient</th>
                                <th>Type</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($appointments as $appointment): ?>
                            <tr>
                                <td>
                                    <strong><?php echo date('g:i A', strtotime($appointment['appointment_time'])); ?></strong><br>
                                    <small class="text-muted"><?php echo $appointment['duration_minutes']; ?> min</small>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                                             style="width: 35px; height: 35px; font-size: 0.8rem;">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div>
                                            <strong><?php echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?></strong><br>
                                            <small class="text-muted">ID: <?php echo htmlspecialchars($appointment['patient_id']); ?></small><br>
                                            <?php if ($appointment['phone']): ?>
                                            <small class="text-muted"><i class="fas fa-phone me-1"></i><?php echo htmlspecialchars($appointment['phone']); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo ucfirst(str_replace('_', ' ', $appointment['appointment_type'])); ?></span>
                                    <?php if ($appointment['country_of_origin']): ?>
                                    <br><small class="text-muted"><?php echo htmlspecialchars($appointment['country_of_origin']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($appointment['reason']): ?>
                                    <?php echo htmlspecialchars(substr($appointment['reason'], 0, 50)) . (strlen($appointment['reason']) > 50 ? '...' : ''); ?>
                                    <?php else: ?>
                                    <span class="text-muted">No reason specified</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo $appointment['status'] === 'confirmed' ? 'success' : 
                                            ($appointment['status'] === 'pending' ? 'warning' : 
                                            ($appointment['status'] === 'completed' ? 'primary' : 
                                            ($appointment['status'] === 'cancelled' ? 'secondary' : 'danger'))); ?>">
                                        <?php echo ucfirst($appointment['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <?php if ($appointment['status'] === 'pending'): ?>
                                        <button class="btn btn-sm btn-success" onclick="updateStatus(<?php echo $appointment['id']; ?>, 'confirmed')">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="updateStatus(<?php echo $appointment['id']; ?>, 'cancelled')">
                                            <i class="fas fa-times"></i>
                                        </button>
                                        <?php elseif ($appointment['status'] === 'confirmed'): ?>
                                        <button class="btn btn-sm btn-primary" onclick="updateStatus(<?php echo $appointment['id']; ?>, 'completed')">
                                            <i class="fas fa-check-double"></i>
                                        </button>
                                        <button class="btn btn-sm btn-warning" onclick="updateStatus(<?php echo $appointment['id']; ?>, 'no_show')">
                                            <i class="fas fa-user-times"></i>
                                        </button>
                                        <?php endif; ?>
                                        
                                        <a href="patient_details.php?id=<?php echo $appointment['patient_id']; ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        <?php if ($appointment['status'] === 'confirmed' || $appointment['status'] === 'completed'): ?>
                                        <a href="add_record.php?patient_id=<?php echo $appointment['patient_id']; ?>" 
                                           class="btn btn-sm btn-outline-success">
                                            <i class="fas fa-plus"></i>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Status Update Form (Hidden) -->
    <form id="statusUpdateForm" method="POST" style="display: none;">
        <input type="hidden" name="update_status" value="1">
        <input type="hidden" name="appointment_id" id="appointmentId">
        <input type="hidden" name="status" id="newStatus">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateStatus(appointmentId, status) {
            const statusNames = {
                'confirmed': 'confirm',
                'cancelled': 'cancel',
                'completed': 'mark as completed',
                'no_show': 'mark as no-show'
            };
            
            if (confirm(`Are you sure you want to ${statusNames[status]} this appointment?`)) {
                document.getElementById('appointmentId').value = appointmentId;
                document.getElementById('newStatus').value = status;
                document.getElementById('statusUpdateForm').submit();
            }
        }
    </script>
</body>
</html>
