<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'doctor') {
    header('Location: ../auth/login.php');
    exit();
}

$error = '';
$success = '';

if ($_POST) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $date_of_birth = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $country_of_origin = trim($_POST['country_of_origin']);
    $current_location = trim($_POST['current_location']);
    $current_address = trim($_POST['current_address']);
    
    // Validation
    if (empty($first_name) || empty($last_name)) {
        $error = 'First name and last name are required.';
    } else {
        try {
            // Generate patient ID
            $stmt = $pdo->query("SELECT MAX(id) as max_id FROM patients");
            $result = $stmt->fetch();
            $next_id = ($result['max_id'] ?? 0) + 1;
            $patient_id = 'PAT' . str_pad($next_id, 6, '0', STR_PAD_LEFT);
            
            // Insert patient record
            $stmt = $pdo->prepare("INSERT INTO patients (patient_id, first_name, last_name, date_of_birth, gender, phone, email, country_of_origin, current_location, current_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$patient_id, $first_name, $last_name, $date_of_birth, $gender, $phone, $email, $country_of_origin, $current_location, $current_address]);
            
            $success = 'Patient added successfully! Patient ID: ' . $patient_id;
            
            // Redirect to patients list after success
            header('Location: patients.php?success=' . urlencode($success));
            exit();
            
        } catch (PDOException $e) {
            $error = 'Error adding patient. Please try again.';
        }
    }
}

// If there's an error, redirect back with error message
if ($error) {
    header('Location: patients.php?error=' . urlencode($error));
    exit();
}

// If accessed directly without POST, redirect to patients page
header('Location: patients.php');
exit();
?>
