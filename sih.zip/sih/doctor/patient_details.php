<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'doctor') {
    header('Location: ../auth/login.php');
    exit();
}

$patient_id = $_GET['id'] ?? '';

if (!$patient_id) {
    header('Location: patients.php');
    exit();
}

// Get patient information
try {
    $stmt = $pdo->prepare("SELECT p.*, u.email, u.phone as user_phone FROM patients p 
                          LEFT JOIN users u ON p.user_id = u.id 
                          WHERE p.id = ?");
    $stmt->execute([$patient_id]);
    $patient = $stmt->fetch();
    
    if (!$patient) {
        header('Location: patients.php');
        exit();
    }
} catch (PDOException $e) {
    header('Location: patients.php');
    exit();
}

// Get medical records
try {
    $stmt = $pdo->prepare("SELECT mr.*, d.first_name as doctor_first_name, d.last_name as doctor_last_name, d.specialization 
                          FROM medical_records mr 
                          LEFT JOIN doctors d ON mr.doctor_id = d.id 
                          WHERE mr.patient_id = ? 
                          ORDER BY mr.visit_date DESC, mr.visit_time DESC");
    $stmt->execute([$patient_id]);
    $medical_records = $stmt->fetchAll();
} catch (PDOException $e) {
    $medical_records = [];
}

// Get prescriptions
try {
    $stmt = $pdo->prepare("SELECT p.*, d.first_name as doctor_first_name, d.last_name as doctor_last_name 
                          FROM prescriptions p 
                          LEFT JOIN doctors d ON p.doctor_id = d.id 
                          WHERE p.patient_id = ? 
                          ORDER BY p.prescribed_date DESC");
    $stmt->execute([$patient_id]);
    $prescriptions = $stmt->fetchAll();
} catch (PDOException $e) {
    $prescriptions = [];
}

// Get vaccinations
try {
    $stmt = $pdo->prepare("SELECT v.*, d.first_name as doctor_first_name, d.last_name as doctor_last_name 
                          FROM vaccinations v 
                          LEFT JOIN doctors d ON v.doctor_id = d.id 
                          WHERE v.patient_id = ? 
                          ORDER BY v.vaccination_date DESC");
    $stmt->execute([$patient_id]);
    $vaccinations = $stmt->fetchAll();
} catch (PDOException $e) {
    $vaccinations = [];
}

// Get medical history
try {
    $stmt = $pdo->prepare("SELECT * FROM medical_history WHERE patient_id = ? ORDER BY diagnosed_date DESC");
    $stmt->execute([$patient_id]);
    $medical_history = $stmt->fetchAll();
} catch (PDOException $e) {
    $medical_history = [];
}

// Get allergies
try {
    $stmt = $pdo->prepare("SELECT * FROM allergies WHERE patient_id = ? ORDER BY created_at DESC");
    $stmt->execute([$patient_id]);
    $allergies = $stmt->fetchAll();
} catch (PDOException $e) {
    $allergies = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Details - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="patients.php">
                            <i class="fas fa-users me-1"></i>Patients
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="records.php">
                            <i class="fas fa-clipboard-list me-1"></i>Records
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-user-circle me-2"></i>Patient Details</h2>
                    <div>
                        <a href="add_record.php?patient_id=<?php echo $patient['id']; ?>" class="btn btn-success me-2">
                            <i class="fas fa-plus me-2"></i>Add Record
                        </a>
                        <a href="patients.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Back to Patients
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Patient Profile Overview -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="profile-avatar mx-auto mb-3 d-flex align-items-center justify-content-center bg-primary text-white" style="width: 100px; height: 100px; border-radius: 50%; font-size: 2.5rem;">
                            <i class="fas fa-user"></i>
                        </div>
                        <h4><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h4>
                        <p class="text-muted mb-2">Patient ID: <?php echo htmlspecialchars($patient['patient_id']); ?></p>
                        <p class="text-muted">
                            <?php 
                            $age = $patient['date_of_birth'] ? date_diff(date_create($patient['date_of_birth']), date_create('today'))->y : 'N/A';
                            echo $age . ' years, ' . ucfirst($patient['gender']); 
                            ?>
                        </p>
                        
                        <div class="row text-start mt-3">
                            <div class="col-12">
                                <?php if ($patient['phone']): ?>
                                <p><i class="fas fa-phone me-2"></i><?php echo htmlspecialchars($patient['phone']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['email']): ?>
                                <p><i class="fas fa-envelope me-2"></i><?php echo htmlspecialchars($patient['email']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['preferred_language']): ?>
                                <p><i class="fas fa-language me-2"></i><?php echo htmlspecialchars($patient['preferred_language']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="card h-100">
                            <div class="card-header">
                                <h6><i class="fas fa-map-marker-alt me-2"></i>Location Information</h6>
                            </div>
                            <div class="card-body">
                                <?php if ($patient['country_of_origin']): ?>
                                <p><strong>Origin:</strong> <?php echo htmlspecialchars($patient['country_of_origin']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['current_location']): ?>
                                <p><strong>Current:</strong> <?php echo htmlspecialchars($patient['current_location']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['current_address']): ?>
                                <p><strong>Address:</strong><br><?php echo nl2br(htmlspecialchars($patient['current_address'])); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="card h-100">
                            <div class="card-header">
                                <h6><i class="fas fa-briefcase me-2"></i>Work Information</h6>
                            </div>
                            <div class="card-body">
                                <?php if ($patient['work_permit_number']): ?>
                                <p><strong>Work Permit:</strong> <?php echo htmlspecialchars($patient['work_permit_number']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['employer_name']): ?>
                                <p><strong>Employer:</strong> <?php echo htmlspecialchars($patient['employer_name']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['employer_contact']): ?>
                                <p><strong>Employer Contact:</strong> <?php echo htmlspecialchars($patient['employer_contact']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <div class="card h-100">
                            <div class="card-header">
                                <h6><i class="fas fa-shield-alt me-2"></i>Insurance</h6>
                            </div>
                            <div class="card-body">
                                <?php if ($patient['insurance_provider']): ?>
                                <p><strong>Provider:</strong> <?php echo htmlspecialchars($patient['insurance_provider']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['insurance_number']): ?>
                                <p><strong>Number:</strong> <?php echo htmlspecialchars($patient['insurance_number']); ?></p>
                                <?php endif; ?>
                                <?php if (!$patient['insurance_provider'] && !$patient['insurance_number']): ?>
                                <p class="text-muted">No insurance information</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <div class="card h-100">
                            <div class="card-header">
                                <h6><i class="fas fa-phone-alt me-2"></i>Emergency Contact</h6>
                            </div>
                            <div class="card-body">
                                <?php if ($patient['emergency_contact_name']): ?>
                                <p><strong>Name:</strong> <?php echo htmlspecialchars($patient['emergency_contact_name']); ?></p>
                                <?php endif; ?>
                                <?php if ($patient['emergency_contact_phone']): ?>
                                <p><strong>Phone:</strong> <?php echo htmlspecialchars($patient['emergency_contact_phone']); ?></p>
                                <?php endif; ?>
                                <?php if (!$patient['emergency_contact_name'] && !$patient['emergency_contact_phone']): ?>
                                <p class="text-muted">No emergency contact</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Medical Information Tabs -->
        <ul class="nav nav-tabs mb-4" id="medicalTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="records-tab" data-bs-toggle="tab" data-bs-target="#records" type="button" role="tab">
                    <i class="fas fa-file-medical me-2"></i>Medical Records (<?php echo count($medical_records); ?>)
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="prescriptions-tab" data-bs-toggle="tab" data-bs-target="#prescriptions" type="button" role="tab">
                    <i class="fas fa-pills me-2"></i>Prescriptions (<?php echo count($prescriptions); ?>)
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="vaccinations-tab" data-bs-toggle="tab" data-bs-target="#vaccinations" type="button" role="tab">
                    <i class="fas fa-syringe me-2"></i>Vaccinations (<?php echo count($vaccinations); ?>)
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="allergies-tab" data-bs-toggle="tab" data-bs-target="#allergies" type="button" role="tab">
                    <i class="fas fa-exclamation-triangle me-2"></i>Allergies (<?php echo count($allergies); ?>)
                </button>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="medicalTabContent">
            <!-- Medical Records Tab -->
            <div class="tab-pane fade show active" id="records" role="tabpanel">
                <?php if (empty($medical_records)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-file-medical fa-3x text-muted mb-3"></i>
                    <h4>No Medical Records</h4>
                    <p class="text-muted">No medical records found for this patient.</p>
                    <a href="add_record.php?patient_id=<?php echo $patient['id']; ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Add First Record
                    </a>
                </div>
                <?php else: ?>
                <div class="row">
                    <?php foreach ($medical_records as $record): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card medical-record-card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">
                                    <i class="fas fa-calendar me-2"></i>
                                    <?php echo date('M d, Y', strtotime($record['visit_date'])); ?>
                                    <?php if ($record['visit_time']): ?>
                                        at <?php echo date('g:i A', strtotime($record['visit_time'])); ?>
                                    <?php endif; ?>
                                </h6>
                                <span class="badge bg-<?php echo $record['record_type'] === 'emergency' ? 'danger' : 'primary'; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $record['record_type'])); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <?php if ($record['doctor_first_name']): ?>
                                <p class="mb-2">
                                    <strong>Doctor:</strong> Dr. <?php echo htmlspecialchars($record['doctor_first_name'] . ' ' . $record['doctor_last_name']); ?>
                                    <?php if ($record['specialization']): ?>
                                        <small class="text-muted">(<?php echo htmlspecialchars($record['specialization']); ?>)</small>
                                    <?php endif; ?>
                                </p>
                                <?php endif; ?>

                                <?php if ($record['chief_complaint']): ?>
                                <p class="mb-2"><strong>Chief Complaint:</strong> <?php echo htmlspecialchars($record['chief_complaint']); ?></p>
                                <?php endif; ?>

                                <?php if ($record['diagnosis']): ?>
                                <p class="mb-2"><strong>Diagnosis:</strong> <?php echo htmlspecialchars($record['diagnosis']); ?></p>
                                <?php endif; ?>

                                <?php if ($record['treatment_plan']): ?>
                                <p class="mb-2"><strong>Treatment:</strong> <?php echo htmlspecialchars($record['treatment_plan']); ?></p>
                                <?php endif; ?>

                                <!-- Vital Signs -->
                                <?php if ($record['blood_pressure'] || $record['heart_rate'] || $record['temperature'] || $record['weight'] || $record['height']): ?>
                                <div class="vital-signs mt-3">
                                    <h6><i class="fas fa-heartbeat me-2"></i>Vital Signs</h6>
                                    <div class="row">
                                        <?php if ($record['blood_pressure']): ?>
                                        <div class="col-6 col-md-4 mb-2">
                                            <div class="vital-sign-item">
                                                <div class="vital-sign-value"><?php echo htmlspecialchars($record['blood_pressure']); ?></div>
                                                <small>Blood Pressure</small>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($record['heart_rate']): ?>
                                        <div class="col-6 col-md-4 mb-2">
                                            <div class="vital-sign-item">
                                                <div class="vital-sign-value"><?php echo $record['heart_rate']; ?></div>
                                                <small>Heart Rate (bpm)</small>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($record['temperature']): ?>
                                        <div class="col-6 col-md-4 mb-2">
                                            <div class="vital-sign-item">
                                                <div class="vital-sign-value"><?php echo $record['temperature']; ?>°F</div>
                                                <small>Temperature</small>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($record['weight']): ?>
                                        <div class="col-6 col-md-4 mb-2">
                                            <div class="vital-sign-item">
                                                <div class="vital-sign-value"><?php echo $record['weight']; ?></div>
                                                <small>Weight (kg)</small>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($record['height']): ?>
                                        <div class="col-6 col-md-4 mb-2">
                                            <div class="vital-sign-item">
                                                <div class="vital-sign-value"><?php echo $record['height']; ?></div>
                                                <small>Height (cm)</small>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if ($record['follow_up_required'] && $record['follow_up_date']): ?>
                                <div class="alert alert-info mt-3">
                                    <i class="fas fa-calendar-check me-2"></i>
                                    <strong>Follow-up Required:</strong> <?php echo date('M d, Y', strtotime($record['follow_up_date'])); ?>
                                    <?php if ($record['follow_up_notes']): ?>
                                        <br><small><?php echo htmlspecialchars($record['follow_up_notes']); ?></small>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Prescriptions Tab -->
            <div class="tab-pane fade" id="prescriptions" role="tabpanel">
                <?php if (empty($prescriptions)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-pills fa-3x text-muted mb-3"></i>
                    <h4>No Prescriptions</h4>
                    <p class="text-muted">No prescriptions found for this patient.</p>
                </div>
                <?php else: ?>
                <div class="row">
                    <?php foreach ($prescriptions as $prescription): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">
                                    <i class="fas fa-pills me-2"></i>
                                    <?php echo htmlspecialchars($prescription['medication_name']); ?>
                                </h6>
                                <span class="badge bg-<?php echo $prescription['status'] === 'active' ? 'success' : ($prescription['status'] === 'completed' ? 'primary' : 'secondary'); ?>">
                                    <?php echo ucfirst($prescription['status']); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <p class="mb-2"><strong>Prescribed Date:</strong> <?php echo date('M d, Y', strtotime($prescription['prescribed_date'])); ?></p>
                                
                                <?php if ($prescription['doctor_first_name']): ?>
                                <p class="mb-2"><strong>Prescribed by:</strong> Dr. <?php echo htmlspecialchars($prescription['doctor_first_name'] . ' ' . $prescription['doctor_last_name']); ?></p>
                                <?php endif; ?>

                                <?php if ($prescription['dosage']): ?>
                                <p class="mb-2"><strong>Dosage:</strong> <?php echo htmlspecialchars($prescription['dosage']); ?></p>
                                <?php endif; ?>

                                <?php if ($prescription['frequency']): ?>
                                <p class="mb-2"><strong>Frequency:</strong> <?php echo htmlspecialchars($prescription['frequency']); ?></p>
                                <?php endif; ?>

                                <?php if ($prescription['duration']): ?>
                                <p class="mb-2"><strong>Duration:</strong> <?php echo htmlspecialchars($prescription['duration']); ?></p>
                                <?php endif; ?>

                                <?php if ($prescription['instructions']): ?>
                                <div class="alert alert-light">
                                    <strong>Instructions:</strong><br>
                                    <?php echo nl2br(htmlspecialchars($prescription['instructions'])); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Vaccinations Tab -->
            <div class="tab-pane fade" id="vaccinations" role="tabpanel">
                <?php if (empty($vaccinations)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-syringe fa-3x text-muted mb-3"></i>
                    <h4>No Vaccination Records</h4>
                    <p class="text-muted">No vaccination records found for this patient.</p>
                </div>
                <?php else: ?>
                <div class="row">
                    <?php foreach ($vaccinations as $vaccination): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-syringe me-2"></i>
                                    <?php echo htmlspecialchars($vaccination['vaccine_name']); ?>
                                </h6>
                            </div>
                            <div class="card-body">
                                <p class="mb-2"><strong>Vaccination Date:</strong> <?php echo date('M d, Y', strtotime($vaccination['vaccination_date'])); ?></p>
                                
                                <?php if ($vaccination['doctor_first_name']): ?>
                                <p class="mb-2"><strong>Administered by:</strong> Dr. <?php echo htmlspecialchars($vaccination['doctor_first_name'] . ' ' . $vaccination['doctor_last_name']); ?></p>
                                <?php endif; ?>

                                <?php if ($vaccination['vaccine_type']): ?>
                                <p class="mb-2"><strong>Type:</strong> <?php echo htmlspecialchars($vaccination['vaccine_type']); ?></p>
                                <?php endif; ?>

                                <?php if ($vaccination['batch_number']): ?>
                                <p class="mb-2"><strong>Batch Number:</strong> <?php echo htmlspecialchars($vaccination['batch_number']); ?></p>
                                <?php endif; ?>

                                <?php if ($vaccination['manufacturer']): ?>
                                <p class="mb-2"><strong>Manufacturer:</strong> <?php echo htmlspecialchars($vaccination['manufacturer']); ?></p>
                                <?php endif; ?>

                                <?php if ($vaccination['location']): ?>
                                <p class="mb-2"><strong>Location:</strong> <?php echo htmlspecialchars($vaccination['location']); ?></p>
                                <?php endif; ?>

                                <?php if ($vaccination['next_due_date']): ?>
                                <div class="alert alert-info">
                                    <i class="fas fa-calendar-alt me-2"></i>
                                    <strong>Next Due:</strong> <?php echo date('M d, Y', strtotime($vaccination['next_due_date'])); ?>
                                </div>
                                <?php endif; ?>

                                <?php if ($vaccination['notes']): ?>
                                <div class="alert alert-light">
                                    <strong>Notes:</strong><br>
                                    <?php echo nl2br(htmlspecialchars($vaccination['notes'])); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Allergies Tab -->
            <div class="tab-pane fade" id="allergies" role="tabpanel">
                <?php if (empty($allergies)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-exclamation-triangle fa-3x text-muted mb-3"></i>
                    <h4>No Known Allergies</h4>
                    <p class="text-muted">No allergies recorded for this patient.</p>
                </div>
                <?php else: ?>
                <div class="row">
                    <?php foreach ($allergies as $allergy): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <?php echo htmlspecialchars($allergy['allergen']); ?>
                                </h6>
                                <span class="badge bg-<?php echo $allergy['severity'] === 'life_threatening' ? 'danger' : ($allergy['severity'] === 'severe' ? 'warning' : 'info'); ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $allergy['severity'])); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <p class="mb-2"><strong>Type:</strong> <?php echo ucfirst(str_replace('_', ' ', $allergy['allergy_type'])); ?></p>
                                
                                <?php if ($allergy['reaction']): ?>
                                <p class="mb-2"><strong>Reaction:</strong> <?php echo htmlspecialchars($allergy['reaction']); ?></p>
                                <?php endif; ?>

                                <?php if ($allergy['notes']): ?>
                                <div class="alert alert-light">
                                    <strong>Notes:</strong><br>
                                    <?php echo nl2br(htmlspecialchars($allergy['notes'])); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
