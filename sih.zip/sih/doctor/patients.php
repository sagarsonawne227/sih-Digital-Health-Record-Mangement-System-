<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'doctor') {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get doctor information
try {
    $stmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: ../auth/login.php');
        exit();
    }
    
    $doctor_id = $doctor['id'];
} catch (PDOException $e) {
    die('Error loading doctor information.');
}

// Handle search
$search = $_GET['search'] ?? '';
$search_condition = '';
$search_params = [];

if ($search) {
    $search_condition = "WHERE (p.first_name LIKE ? OR p.last_name LIKE ? OR p.patient_id LIKE ? OR p.country_of_origin LIKE ?)";
    $search_params = ["%$search%", "%$search%", "%$search%", "%$search%"];
}

// Get patients
try {
    $stmt = $pdo->prepare("SELECT p.*, 
                          (SELECT COUNT(*) FROM medical_records mr WHERE mr.patient_id = p.id) as record_count,
                          (SELECT MAX(visit_date) FROM medical_records mr WHERE mr.patient_id = p.id) as last_visit
                          FROM patients p 
                          $search_condition
                          ORDER BY p.created_at DESC");
    $stmt->execute($search_params);
    $patients = $stmt->fetchAll();
} catch (PDOException $e) {
    $patients = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="patients.php">
                            <i class="fas fa-users me-1"></i>Patients
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="records.php">
                            <i class="fas fa-clipboard-list me-1"></i>Records
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-users me-2"></i>Patient Management</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPatientModal">
                        <i class="fas fa-user-plus me-2"></i>Add New Patient
                    </button>
                </div>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="row mb-4">
            <div class="col-md-6">
                <form method="GET" action="">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Search patients by name, ID, or country..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                        <button class="btn btn-outline-primary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                        <?php if ($search): ?>
                        <a href="patients.php" class="btn btn-outline-secondary">
                            <i class="fas fa-times"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            <div class="col-md-6 text-end">
                <span class="text-muted">Total Patients: <?php echo count($patients); ?></span>
            </div>
        </div>

        <!-- Patients Table -->
        <?php if (empty($patients)): ?>
        <div class="text-center py-5">
            <i class="fas fa-users fa-3x text-muted mb-3"></i>
            <h4><?php echo $search ? 'No patients found' : 'No patients registered'; ?></h4>
            <p class="text-muted">
                <?php echo $search ? 'Try adjusting your search criteria.' : 'Patients will appear here once they register or are added to the system.'; ?>
            </p>
        </div>
        <?php else: ?>
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Patient Info</th>
                                <th>Contact</th>
                                <th>Origin/Location</th>
                                <th>Records</th>
                                <th>Last Visit</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($patients as $patient): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                                             style="width: 40px; height: 40px;">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div>
                                            <strong><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></strong><br>
                                            <small class="text-muted">ID: <?php echo htmlspecialchars($patient['patient_id']); ?></small><br>
                                            <small class="text-muted">
                                                <?php 
                                                $age = $patient['date_of_birth'] ? date_diff(date_create($patient['date_of_birth']), date_create('today'))->y : 'N/A';
                                                echo $age . ' years, ' . ucfirst($patient['gender']); 
                                                ?>
                                            </small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($patient['phone']): ?>
                                    <i class="fas fa-phone me-1"></i><?php echo htmlspecialchars($patient['phone']); ?><br>
                                    <?php endif; ?>
                                    <?php if ($patient['email']): ?>
                                    <i class="fas fa-envelope me-1"></i><?php echo htmlspecialchars($patient['email']); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($patient['country_of_origin']): ?>
                                    <strong>From:</strong> <?php echo htmlspecialchars($patient['country_of_origin']); ?><br>
                                    <?php endif; ?>
                                    <?php if ($patient['current_location']): ?>
                                    <strong>Current:</strong> <?php echo htmlspecialchars($patient['current_location']); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo $patient['record_count']; ?> Records</span>
                                </td>
                                <td>
                                    <?php if ($patient['last_visit']): ?>
                                    <?php echo date('M d, Y', strtotime($patient['last_visit'])); ?>
                                    <?php else: ?>
                                    <span class="text-muted">No visits</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="patient_details.php?id=<?php echo $patient['id']; ?>" 
                                           class="btn btn-sm btn-outline-primary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="add_record.php?patient_id=<?php echo $patient['id']; ?>" 
                                           class="btn btn-sm btn-outline-success" title="Add Record">
                                            <i class="fas fa-plus"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Add Patient Modal -->
    <div class="modal fade" id="addPatientModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Add New Patient</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="add_patient.php">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">First Name *</label>
                                <input type="text" class="form-control" name="first_name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Last Name *</label>
                                <input type="text" class="form-control" name="last_name" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" name="date_of_birth">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Gender</label>
                                <select class="form-select" name="gender">
                                    <option value="">Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone</label>
                                <input type="tel" class="form-control" name="phone">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Country of Origin</label>
                                <input type="text" class="form-control" name="country_of_origin">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Current Location</label>
                                <input type="text" class="form-control" name="current_location">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Current Address</label>
                            <textarea class="form-control" name="current_address" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Add Patient
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
