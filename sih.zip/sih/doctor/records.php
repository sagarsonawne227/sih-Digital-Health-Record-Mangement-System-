<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'doctor') {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get doctor information
try {
    $stmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $doctor = $stmt->fetch();
    
    if (!$doctor) {
        header('Location: ../auth/login.php');
        exit();
    }
    
    $doctor_id = $doctor['id'];
} catch (PDOException $e) {
    die('Error loading doctor information.');
}

// Handle search and filters
$search = $_GET['search'] ?? '';
$record_type = $_GET['record_type'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

$search_conditions = [];
$search_params = [];

if ($search) {
    $search_conditions[] = "(p.first_name LIKE ? OR p.last_name LIKE ? OR p.patient_id LIKE ? OR mr.diagnosis LIKE ? OR mr.chief_complaint LIKE ?)";
    $search_params = array_merge($search_params, ["%$search%", "%$search%", "%$search%", "%$search%", "%$search%"]);
}

if ($record_type) {
    $search_conditions[] = "mr.record_type = ?";
    $search_params[] = $record_type;
}

if ($date_from) {
    $search_conditions[] = "mr.visit_date >= ?";
    $search_params[] = $date_from;
}

if ($date_to) {
    $search_conditions[] = "mr.visit_date <= ?";
    $search_params[] = $date_to;
}

$where_clause = '';
if (!empty($search_conditions)) {
    $where_clause = 'WHERE ' . implode(' AND ', $search_conditions);
}

// Get medical records
try {
    $stmt = $pdo->prepare("SELECT mr.*, p.first_name, p.last_name, p.patient_id, p.country_of_origin, p.current_location,
                          d.first_name as doctor_first_name, d.last_name as doctor_last_name
                          FROM medical_records mr 
                          JOIN patients p ON mr.patient_id = p.id 
                          LEFT JOIN doctors d ON mr.doctor_id = d.id 
                          $where_clause
                          ORDER BY mr.visit_date DESC, mr.visit_time DESC");
    $stmt->execute($search_params);
    $medical_records = $stmt->fetchAll();
} catch (PDOException $e) {
    $medical_records = [];
}

// Get record type counts for filter
try {
    $stmt = $pdo->query("SELECT record_type, COUNT(*) as count FROM medical_records GROUP BY record_type");
    $record_type_counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    $record_type_counts = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Records - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="patients.php">
                            <i class="fas fa-users me-1"></i>Patients
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="records.php">
                            <i class="fas fa-clipboard-list me-1"></i>Records
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <h2><i class="fas fa-clipboard-list me-2"></i>Medical Records</h2>
                <p class="text-muted">Search and manage all medical records</p>
            </div>
        </div>

        <!-- Search and Filter Panel -->
        <div class="card mb-4">
            <div class="card-header">
                <h5><i class="fas fa-search me-2"></i>Search & Filter</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Search</label>
                            <input type="text" class="form-control" name="search" 
                                   placeholder="Patient name, ID, diagnosis..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Record Type</label>
                            <select class="form-select" name="record_type">
                                <option value="">All Types</option>
                                <option value="consultation" <?php echo $record_type === 'consultation' ? 'selected' : ''; ?>>Consultation</option>
                                <option value="diagnosis" <?php echo $record_type === 'diagnosis' ? 'selected' : ''; ?>>Diagnosis</option>
                                <option value="prescription" <?php echo $record_type === 'prescription' ? 'selected' : ''; ?>>Prescription</option>
                                <option value="lab_result" <?php echo $record_type === 'lab_result' ? 'selected' : ''; ?>>Lab Result</option>
                                <option value="vaccination" <?php echo $record_type === 'vaccination' ? 'selected' : ''; ?>>Vaccination</option>
                                <option value="emergency" <?php echo $record_type === 'emergency' ? 'selected' : ''; ?>>Emergency</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">From Date</label>
                            <input type="date" class="form-control" name="date_from" 
                                   value="<?php echo htmlspecialchars($date_from); ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">To Date</label>
                            <input type="date" class="form-control" name="date_to" 
                                   value="<?php echo htmlspecialchars($date_to); ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">&nbsp;</label>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search me-1"></i>Search
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php if ($search || $record_type || $date_from || $date_to): ?>
                    <div class="row">
                        <div class="col-12">
                            <a href="records.php" class="btn btn-outline-secondary btn-sm">
                                <i class="fas fa-times me-1"></i>Clear Filters
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-2 mb-3">
                <div class="card bg-primary text-white">
                    <div class="card-body text-center">
                        <h4><?php echo count($medical_records); ?></h4>
                        <small>Total Records</small>
                    </div>
                </div>
            </div>
            <?php foreach ($record_type_counts as $type => $count): ?>
            <div class="col-md-2 mb-3">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <h5><?php echo $count; ?></h5>
                        <small><?php echo ucfirst(str_replace('_', ' ', $type)); ?></small>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Records List -->
        <?php if (empty($medical_records)): ?>
        <div class="text-center py-5">
            <i class="fas fa-file-medical fa-3x text-muted mb-3"></i>
            <h4>No Medical Records Found</h4>
            <p class="text-muted">
                <?php echo ($search || $record_type || $date_from || $date_to) ? 'Try adjusting your search criteria.' : 'Medical records will appear here as they are created.'; ?>
            </p>
        </div>
        <?php else: ?>
        <div class="row">
            <?php foreach ($medical_records as $record): ?>
            <div class="col-md-6 mb-4">
                <div class="card medical-record-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-0">
                                <i class="fas fa-user me-2"></i>
                                <?php echo htmlspecialchars($record['first_name'] . ' ' . $record['last_name']); ?>
                            </h6>
                            <small class="text-muted">ID: <?php echo htmlspecialchars($record['patient_id']); ?></small>
                        </div>
                        <span class="badge bg-<?php echo $record['record_type'] === 'emergency' ? 'danger' : 'primary'; ?>">
                            <?php echo ucfirst(str_replace('_', ' ', $record['record_type'])); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-6">
                                <strong>Date:</strong> <?php echo date('M d, Y', strtotime($record['visit_date'])); ?>
                                <?php if ($record['visit_time']): ?>
                                    <br><strong>Time:</strong> <?php echo date('g:i A', strtotime($record['visit_time'])); ?>
                                <?php endif; ?>
                            </div>
                            <div class="col-6">
                                <?php if ($record['country_of_origin']): ?>
                                <strong>Origin:</strong> <?php echo htmlspecialchars($record['country_of_origin']); ?><br>
                                <?php endif; ?>
                                <?php if ($record['current_location']): ?>
                                <strong>Location:</strong> <?php echo htmlspecialchars($record['current_location']); ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if ($record['doctor_first_name']): ?>
                        <p class="mb-2">
                            <strong>Doctor:</strong> Dr. <?php echo htmlspecialchars($record['doctor_first_name'] . ' ' . $record['doctor_last_name']); ?>
                        </p>
                        <?php endif; ?>

                        <?php if ($record['chief_complaint']): ?>
                        <p class="mb-2"><strong>Chief Complaint:</strong> <?php echo htmlspecialchars($record['chief_complaint']); ?></p>
                        <?php endif; ?>

                        <?php if ($record['diagnosis']): ?>
                        <p class="mb-2"><strong>Diagnosis:</strong> <?php echo htmlspecialchars($record['diagnosis']); ?></p>
                        <?php endif; ?>

                        <?php if ($record['treatment_plan']): ?>
                        <p class="mb-2"><strong>Treatment:</strong> <?php echo htmlspecialchars($record['treatment_plan']); ?></p>
                        <?php endif; ?>

                        <!-- Vital Signs Summary -->
                        <?php if ($record['blood_pressure'] || $record['heart_rate'] || $record['temperature']): ?>
                        <div class="alert alert-light">
                            <strong>Vitals:</strong>
                            <?php if ($record['blood_pressure']): ?>BP: <?php echo htmlspecialchars($record['blood_pressure']); ?> <?php endif; ?>
                            <?php if ($record['heart_rate']): ?>HR: <?php echo $record['heart_rate']; ?>bpm <?php endif; ?>
                            <?php if ($record['temperature']): ?>Temp: <?php echo $record['temperature']; ?>°F<?php endif; ?>
                        </div>
                        <?php endif; ?>

                        <?php if ($record['follow_up_required'] && $record['follow_up_date']): ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-calendar-check me-2"></i>
                            <strong>Follow-up:</strong> <?php echo date('M d, Y', strtotime($record['follow_up_date'])); ?>
                        </div>
                        <?php endif; ?>

                        <div class="text-end">
                            <a href="patient_details.php?id=<?php echo $record['patient_id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye me-1"></i>View Patient
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
