<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'patient') {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Get patient information
try {
    $stmt = $pdo->prepare("SELECT p.*, u.email, u.phone as user_phone FROM patients p 
                          JOIN users u ON p.user_id = u.id 
                          WHERE p.user_id = ?");
    $stmt->execute([$user_id]);
    $patient = $stmt->fetch();
    
    if (!$patient) {
        header('Location: ../auth/login.php');
        exit();
    }
} catch (PDOException $e) {
    $error = 'Error loading profile information.';
}

// Handle profile update
if ($_POST && isset($_POST['update_profile'])) {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $date_of_birth = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $country_of_origin = trim($_POST['country_of_origin']);
    $current_location = trim($_POST['current_location']);
    $preferred_language = $_POST['preferred_language'];
    $current_address = trim($_POST['current_address']);
    $permanent_address = trim($_POST['permanent_address']);
    $work_permit_number = trim($_POST['work_permit_number']);
    $employer_name = trim($_POST['employer_name']);
    $employer_contact = trim($_POST['employer_contact']);
    $insurance_provider = trim($_POST['insurance_provider']);
    $insurance_number = trim($_POST['insurance_number']);
    $emergency_contact_name = trim($_POST['emergency_contact_name']);
    $emergency_contact_phone = trim($_POST['emergency_contact_phone']);
    
    try {
        $pdo->beginTransaction();
        
        // Update users table
        $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, phone = ?, email = ? WHERE id = ?");
        $stmt->execute([$first_name, $last_name, $phone, $email, $user_id]);
        
        // Update patients table
        $stmt = $pdo->prepare("UPDATE patients SET 
                              first_name = ?, last_name = ?, phone = ?, email = ?, 
                              date_of_birth = ?, gender = ?, country_of_origin = ?, 
                              current_location = ?, preferred_language = ?, current_address = ?, 
                              permanent_address = ?, work_permit_number = ?, employer_name = ?, 
                              employer_contact = ?, insurance_provider = ?, insurance_number = ?,
                              emergency_contact_name = ?, emergency_contact_phone = ?
                              WHERE user_id = ?");
        $stmt->execute([$first_name, $last_name, $phone, $email, $date_of_birth, $gender, 
                       $country_of_origin, $current_location, $preferred_language, $current_address,
                       $permanent_address, $work_permit_number, $employer_name, $employer_contact,
                       $insurance_provider, $insurance_number, $emergency_contact_name, 
                       $emergency_contact_phone, $user_id]);
        
        $pdo->commit();
        $success = 'Profile updated successfully!';
        
        // Refresh patient data
        $stmt = $pdo->prepare("SELECT p.*, u.email, u.phone as user_phone FROM patients p 
                              JOIN users u ON p.user_id = u.id 
                              WHERE p.user_id = ?");
        $stmt->execute([$user_id]);
        $patient = $stmt->fetch();
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = 'Error updating profile. Please try again.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="profile.php">
                            <i class="fas fa-user me-1"></i>My Profile
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="records.php">
                            <i class="fas fa-file-medical me-1"></i>My Records
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-user-circle me-2"></i>My Profile</h2>
                    <button class="btn btn-primary" onclick="toggleEditMode()">
                        <i class="fas fa-edit me-2"></i>Edit Profile
                    </button>
                </div>
            </div>
        </div>

        <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="row">
                <!-- Personal Information -->
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5><i class="fas fa-user me-2"></i>Personal Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="text-center mb-4">
                                <div class="profile-avatar mx-auto mb-3 d-flex align-items-center justify-content-center bg-primary text-white" style="width: 100px; height: 100px; border-radius: 50%; font-size: 2rem;">
                                    <i class="fas fa-user"></i>
                                </div>
                                <h5><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></h5>
                                <p class="text-muted">Patient ID: <?php echo htmlspecialchars($patient['patient_id']); ?></p>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">First Name</label>
                                    <input type="text" class="form-control" name="first_name" 
                                           value="<?php echo htmlspecialchars($patient['first_name']); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" class="form-control" name="last_name" 
                                           value="<?php echo htmlspecialchars($patient['last_name']); ?>" readonly>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Date of Birth</label>
                                    <input type="date" class="form-control" name="date_of_birth" 
                                           value="<?php echo htmlspecialchars($patient['date_of_birth']); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Gender</label>
                                    <select class="form-select" name="gender" disabled>
                                        <option value="male" <?php echo $patient['gender'] === 'male' ? 'selected' : ''; ?>>Male</option>
                                        <option value="female" <?php echo $patient['gender'] === 'female' ? 'selected' : ''; ?>>Female</option>
                                        <option value="other" <?php echo $patient['gender'] === 'other' ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="tel" class="form-control" name="phone" 
                                           value="<?php echo htmlspecialchars($patient['phone']); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" 
                                           value="<?php echo htmlspecialchars($patient['email']); ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Preferred Language</label>
                                <select class="form-select" name="preferred_language" disabled>
                                    <option value="English" <?php echo $patient['preferred_language'] === 'English' ? 'selected' : ''; ?>>English</option>
                                    <option value="Arabic" <?php echo $patient['preferred_language'] === 'Arabic' ? 'selected' : ''; ?>>العربية (Arabic)</option>
                                    <option value="Spanish" <?php echo $patient['preferred_language'] === 'Spanish' ? 'selected' : ''; ?>>Español (Spanish)</option>
                                    <option value="French" <?php echo $patient['preferred_language'] === 'French' ? 'selected' : ''; ?>>Français (French)</option>
                                    <option value="Hindi" <?php echo $patient['preferred_language'] === 'Hindi' ? 'selected' : ''; ?>>हिन्दी (Hindi)</option>
                                    <option value="Urdu" <?php echo $patient['preferred_language'] === 'Urdu' ? 'selected' : ''; ?>>اردو (Urdu)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Location & Work Information -->
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5><i class="fas fa-map-marker-alt me-2"></i>Location & Work Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Country of Origin</label>
                                    <input type="text" class="form-control" name="country_of_origin" 
                                           value="<?php echo htmlspecialchars($patient['country_of_origin']); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Current Location</label>
                                    <input type="text" class="form-control" name="current_location" 
                                           value="<?php echo htmlspecialchars($patient['current_location']); ?>" readonly>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Current Address</label>
                                <textarea class="form-control" name="current_address" rows="3" readonly><?php echo htmlspecialchars($patient['current_address']); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Permanent Address</label>
                                <textarea class="form-control" name="permanent_address" rows="3" readonly><?php echo htmlspecialchars($patient['permanent_address']); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Work Permit Number</label>
                                <input type="text" class="form-control" name="work_permit_number" 
                                       value="<?php echo htmlspecialchars($patient['work_permit_number']); ?>" readonly>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Employer Name</label>
                                    <input type="text" class="form-control" name="employer_name" 
                                           value="<?php echo htmlspecialchars($patient['employer_name']); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Employer Contact</label>
                                    <input type="text" class="form-control" name="employer_contact" 
                                           value="<?php echo htmlspecialchars($patient['employer_contact']); ?>" readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Insurance Information -->
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5><i class="fas fa-shield-alt me-2"></i>Insurance Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Insurance Provider</label>
                                <input type="text" class="form-control" name="insurance_provider" 
                                       value="<?php echo htmlspecialchars($patient['insurance_provider']); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Insurance Number</label>
                                <input type="text" class="form-control" name="insurance_number" 
                                       value="<?php echo htmlspecialchars($patient['insurance_number']); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Emergency Contact -->
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5><i class="fas fa-phone-alt me-2"></i>Emergency Contact</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label class="form-label">Contact Name</label>
                                <input type="text" class="form-control" name="emergency_contact_name" 
                                       value="<?php echo htmlspecialchars($patient['emergency_contact_name']); ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Contact Phone</label>
                                <input type="tel" class="form-control" name="emergency_contact_phone" 
                                       value="<?php echo htmlspecialchars($patient['emergency_contact_phone']); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row edit-mode" style="display: none;">
                <div class="col-12">
                    <div class="text-center">
                        <button type="submit" name="update_profile" class="btn btn-success me-3">
                            <i class="fas fa-save me-2"></i>Save Changes
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="cancelEdit()">
                            <i class="fas fa-times me-2"></i>Cancel
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleEditMode() {
            const inputs = document.querySelectorAll('input, textarea, select');
            const editModeElements = document.querySelectorAll('.edit-mode');
            
            inputs.forEach(input => {
                if (input.hasAttribute('readonly')) {
                    input.removeAttribute('readonly');
                } else if (input.hasAttribute('disabled')) {
                    input.removeAttribute('disabled');
                }
            });
            
            editModeElements.forEach(element => {
                element.style.display = 'block';
            });
            
            // Hide edit button
            document.querySelector('button[onclick="toggleEditMode()"]').style.display = 'none';
        }
        
        function cancelEdit() {
            location.reload();
        }
    </script>
</body>
</html>
