<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'patient') {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get patient ID
try {
    $stmt = $pdo->prepare("SELECT id, patient_id FROM patients WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $patient = $stmt->fetch();
    
    if (!$patient) {
        header('Location: ../auth/login.php');
        exit();
    }
    
    $patient_id = $patient['id'];
} catch (PDOException $e) {
    die('Error loading patient information.');
}

// Get appointments
try {
    $stmt = $pdo->prepare("SELECT a.*, d.first_name as doctor_first_name, d.last_name as doctor_last_name, d.specialization, d.hospital_clinic 
                          FROM appointments a 
                          LEFT JOIN doctors d ON a.doctor_id = d.id 
                          WHERE a.patient_id = ? 
                          ORDER BY a.appointment_date DESC, a.appointment_time DESC");
    $stmt->execute([$patient_id]);
    $appointments = $stmt->fetchAll();
} catch (PDOException $e) {
    $appointments = [];
}

// Get available doctors for booking
try {
    $stmt = $pdo->query("SELECT id, doctor_id, first_name, last_name, specialization, hospital_clinic FROM doctors ORDER BY first_name, last_name");
    $doctors = $stmt->fetchAll();
} catch (PDOException $e) {
    $doctors = [];
}

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Appointments - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-heartbeat me-2"></i>Health Records System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user me-1"></i>My Profile
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="records.php">
                            <i class="fas fa-file-medical me-1"></i>My Records
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="appointments.php">
                            <i class="fas fa-calendar-check me-1"></i>Appointments
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-calendar-check me-2"></i>My Appointments</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bookAppointmentModal">
                        <i class="fas fa-plus me-2"></i>Book Appointment
                    </button>
                </div>
            </div>
        </div>

        <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Appointments List -->
        <?php if (empty($appointments)): ?>
        <div class="text-center py-5">
            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
            <h4>No Appointments Found</h4>
            <p class="text-muted">You haven't booked any appointments yet.</p>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bookAppointmentModal">
                <i class="fas fa-plus me-2"></i>Book Your First Appointment
            </button>
        </div>
        <?php else: ?>
        <div class="row">
            <?php foreach ($appointments as $appointment): ?>
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">
                            <i class="fas fa-calendar me-2"></i>
                            <?php echo date('M d, Y', strtotime($appointment['appointment_date'])); ?>
                            at <?php echo date('g:i A', strtotime($appointment['appointment_time'])); ?>
                        </h6>
                        <span class="badge bg-<?php 
                            echo $appointment['status'] === 'confirmed' ? 'success' : 
                                ($appointment['status'] === 'pending' ? 'warning' : 
                                ($appointment['status'] === 'completed' ? 'primary' : 
                                ($appointment['status'] === 'cancelled' ? 'secondary' : 'danger'))); ?>">
                            <?php echo ucfirst($appointment['status']); ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <?php if ($appointment['doctor_first_name']): ?>
                        <p class="mb-2">
                            <strong>Doctor:</strong> Dr. <?php echo htmlspecialchars($appointment['doctor_first_name'] . ' ' . $appointment['doctor_last_name']); ?>
                            <?php if ($appointment['specialization']): ?>
                                <br><small class="text-muted"><?php echo htmlspecialchars($appointment['specialization']); ?></small>
                            <?php endif; ?>
                        </p>
                        <?php endif; ?>

                        <?php if ($appointment['hospital_clinic']): ?>
                        <p class="mb-2"><strong>Location:</strong> <?php echo htmlspecialchars($appointment['hospital_clinic']); ?></p>
                        <?php endif; ?>

                        <p class="mb-2"><strong>Type:</strong> <?php echo ucfirst(str_replace('_', ' ', $appointment['appointment_type'])); ?></p>

                        <?php if ($appointment['duration_minutes']): ?>
                        <p class="mb-2"><strong>Duration:</strong> <?php echo $appointment['duration_minutes']; ?> minutes</p>
                        <?php endif; ?>

                        <?php if ($appointment['reason']): ?>
                        <p class="mb-2"><strong>Reason:</strong> <?php echo htmlspecialchars($appointment['reason']); ?></p>
                        <?php endif; ?>

                        <?php if ($appointment['notes']): ?>
                        <div class="alert alert-light">
                            <strong>Notes:</strong><br>
                            <?php echo nl2br(htmlspecialchars($appointment['notes'])); ?>
                        </div>
                        <?php endif; ?>

                        <?php if ($appointment['status'] === 'pending' && strtotime($appointment['appointment_date']) > time()): ?>
                        <div class="text-end">
                            <button class="btn btn-sm btn-outline-danger" onclick="cancelAppointment(<?php echo $appointment['id']; ?>)">
                                <i class="fas fa-times me-1"></i>Cancel
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Book Appointment Modal -->
    <div class="modal fade" id="bookAppointmentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-calendar-plus me-2"></i>Book Appointment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="book_appointment.php">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Doctor *</label>
                            <select class="form-select" name="doctor_id" required>
                                <option value="">Select Doctor</option>
                                <?php foreach ($doctors as $doctor): ?>
                                <option value="<?php echo $doctor['id']; ?>">
                                    Dr. <?php echo htmlspecialchars($doctor['first_name'] . ' ' . $doctor['last_name']); ?>
                                    <?php if ($doctor['specialization']): ?>
                                        - <?php echo htmlspecialchars($doctor['specialization']); ?>
                                    <?php endif; ?>
                                    <?php if ($doctor['hospital_clinic']): ?>
                                        (<?php echo htmlspecialchars($doctor['hospital_clinic']); ?>)
                                    <?php endif; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Appointment Date *</label>
                                <input type="date" class="form-control" name="appointment_date" 
                                       min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Appointment Time *</label>
                                <input type="time" class="form-control" name="appointment_time" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Appointment Type *</label>
                                <select class="form-select" name="appointment_type" required>
                                    <option value="">Select Type</option>
                                    <option value="consultation">Consultation</option>
                                    <option value="follow_up">Follow-up</option>
                                    <option value="emergency">Emergency</option>
                                    <option value="vaccination">Vaccination</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Duration (minutes)</label>
                                <select class="form-select" name="duration_minutes">
                                    <option value="30">30 minutes</option>
                                    <option value="45">45 minutes</option>
                                    <option value="60">1 hour</option>
                                    <option value="90">1.5 hours</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Reason for Visit</label>
                            <textarea class="form-control" name="reason" rows="3" 
                                      placeholder="Please describe the reason for your appointment"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-calendar-plus me-2"></i>Book Appointment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function cancelAppointment(appointmentId) {
            if (confirm('Are you sure you want to cancel this appointment?')) {
                window.location.href = 'cancel_appointment.php?id=' + appointmentId;
            }
        }
    </script>
</body>
</html>
