<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a patient
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'patient') {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get patient ID
try {
    $stmt = $pdo->prepare("SELECT id FROM patients WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $patient = $stmt->fetch();
    
    if (!$patient) {
        header('Location: ../auth/login.php');
        exit();
    }
    
    $patient_id = $patient['id'];
} catch (PDOException $e) {
    header('Location: appointments.php?error=' . urlencode('Error loading patient information.'));
    exit();
}

if ($_POST) {
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $appointment_type = $_POST['appointment_type'];
    $duration_minutes = $_POST['duration_minutes'] ?? 30;
    $reason = trim($_POST['reason']);
    
    // Validation
    if (empty($doctor_id) || empty($appointment_date) || empty($appointment_time) || empty($appointment_type)) {
        header('Location: appointments.php?error=' . urlencode('Please fill in all required fields.'));
        exit();
    }
    
    // Check if appointment date is not in the past
    if (strtotime($appointment_date) < strtotime('today')) {
        header('Location: appointments.php?error=' . urlencode('Appointment date cannot be in the past.'));
        exit();
    }
    
    try {
        // Check for conflicting appointments
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM appointments 
                              WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ? 
                              AND status NOT IN ('cancelled', 'no_show')");
        $stmt->execute([$doctor_id, $appointment_date, $appointment_time]);
        $conflict_count = $stmt->fetchColumn();
        
        if ($conflict_count > 0) {
            header('Location: appointments.php?error=' . urlencode('This time slot is already booked. Please choose a different time.'));
            exit();
        }
        
        // Insert appointment
        $stmt = $pdo->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, duration_minutes, status, appointment_type, reason) VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)");
        $stmt->execute([$patient_id, $doctor_id, $appointment_date, $appointment_time, $duration_minutes, $appointment_type, $reason]);
        
        header('Location: appointments.php?success=' . urlencode('Appointment booked successfully! You will receive confirmation soon.'));
        exit();
        
    } catch (PDOException $e) {
        header('Location: appointments.php?error=' . urlencode('Error booking appointment. Please try again.'));
        exit();
    }
}

// If accessed directly without POST, redirect to appointments page
header('Location: appointments.php');
exit();
?>
