<?php
session_start();
require_once '../config/database.php';

// Log logout action
if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("INSERT INTO system_logs (user_id, action, ip_address, user_agent) VALUES (?, 'logout', ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
    } catch (PDOException $e) {
        // Silent fail for logging
    }
}

// Destroy session
session_destroy();

// Redirect to login
header('Location: login.php');
exit();
?>
