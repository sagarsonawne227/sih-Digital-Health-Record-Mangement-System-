<?php
// Installation and System Check Script
error_reporting(E_ALL);
ini_set('display_errors', 1);

$checks = [];
$overall_status = true;

// Check PHP version
$php_version = phpversion();
$checks['php_version'] = [
    'name' => 'PHP Version',
    'status' => version_compare($php_version, '7.4.0', '>='),
    'message' => $php_version . (version_compare($php_version, '7.4.0', '>=') ? ' ✓' : ' (Requires 7.4+)'),
    'required' => true
];

// Check required PHP extensions
$required_extensions = ['pdo', 'pdo_mysql', 'mysqli', 'json', 'session', 'openssl'];
foreach ($required_extensions as $ext) {
    $loaded = extension_loaded($ext);
    $checks['ext_' . $ext] = [
        'name' => "PHP Extension: $ext",
        'status' => $loaded,
        'message' => $loaded ? 'Loaded ✓' : 'Missing ✗',
        'required' => true
    ];
    if (!$loaded) $overall_status = false;
}

// Check file permissions
$writable_dirs = ['logs'];
foreach ($writable_dirs as $dir) {
    $path = __DIR__ . '/' . $dir;
    $writable = is_dir($path) ? is_writable($path) : (mkdir($path, 0755, true) && is_writable($path));
    $checks['perm_' . $dir] = [
        'name' => "Directory Writable: $dir",
        'status' => $writable,
        'message' => $writable ? 'Writable ✓' : 'Not writable ✗',
        'required' => false
    ];
}

// Check database connection
try {
    require_once 'config/database.php';
    $checks['db_connection'] = [
        'name' => 'Database Connection',
        'status' => true,
        'message' => 'Connected successfully ✓',
        'required' => true
    ];
    
    // Check if tables exist
    $tables = ['users', 'patients', 'doctors', 'medical_records', 'prescriptions', 'vaccinations', 'appointments'];
    $existing_tables = [];
    
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT 1 FROM $table LIMIT 1");
            $existing_tables[] = $table;
        } catch (PDOException $e) {
            // Table doesn't exist
        }
    }
    
    $checks['db_tables'] = [
        'name' => 'Database Tables',
        'status' => count($existing_tables) === count($tables),
        'message' => count($existing_tables) . '/' . count($tables) . ' tables found' . (count($existing_tables) === count($tables) ? ' ✓' : ' ✗'),
        'required' => true,
        'details' => $existing_tables
    ];
    
    if (count($existing_tables) !== count($tables)) {
        $overall_status = false;
    }
    
    // Check sample data
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM users");
        $user_count = $stmt->fetchColumn();
        $checks['sample_data'] = [
            'name' => 'Sample Data',
            'status' => $user_count > 0,
            'message' => "$user_count users found" . ($user_count > 0 ? ' ✓' : ' ✗'),
            'required' => false
        ];
    } catch (PDOException $e) {
        $checks['sample_data'] = [
            'name' => 'Sample Data',
            'status' => false,
            'message' => 'Cannot check sample data ✗',
            'required' => false
        ];
    }
    
} catch (Exception $e) {
    $checks['db_connection'] = [
        'name' => 'Database Connection',
        'status' => false,
        'message' => 'Connection failed: ' . $e->getMessage() . ' ✗',
        'required' => true
    ];
    $overall_status = false;
}

// Update overall status based on required checks
foreach ($checks as $check) {
    if ($check['required'] && !$check['status']) {
        $overall_status = false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Installation Check - Digital Health Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h2><i class="fas fa-heartbeat me-2"></i>Digital Health Records System</h2>
                        <h4>Installation Check</h4>
                    </div>
                    <div class="card-body">
                        <!-- Overall Status -->
                        <div class="alert alert-<?php echo $overall_status ? 'success' : 'danger'; ?> text-center">
                            <h4>
                                <i class="fas fa-<?php echo $overall_status ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
                                System Status: <?php echo $overall_status ? 'Ready' : 'Needs Setup'; ?>
                            </h4>
                            <?php if ($overall_status): ?>
                            <p class="mb-0">All required components are properly configured!</p>
                            <a href="auth/login.php" class="btn btn-success mt-3">
                                <i class="fas fa-sign-in-alt me-2"></i>Go to Login
                            </a>
                            <?php else: ?>
                            <p class="mb-0">Please fix the issues below before using the system.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Detailed Checks -->
                        <h5>System Requirements</h5>
                        <div class="list-group mb-4">
                            <?php foreach ($checks as $key => $check): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo htmlspecialchars($check['name']); ?></strong>
                                    <?php if ($check['required']): ?>
                                    <span class="badge bg-warning ms-2">Required</span>
                                    <?php endif; ?>
                                    <?php if (isset($check['details'])): ?>
                                    <br><small class="text-muted">Tables: <?php echo implode(', ', $check['details']); ?></small>
                                    <?php endif; ?>
                                </div>
                                <span class="<?php echo $check['status'] ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo htmlspecialchars($check['message']); ?>
                                </span>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Setup Instructions -->
                        <?php if (!$overall_status): ?>
                        <div class="card bg-light">
                            <div class="card-header">
                                <h5><i class="fas fa-tools me-2"></i>Setup Instructions</h5>
                            </div>
                            <div class="card-body">
                                <h6>Database Setup:</h6>
                                <ol>
                                    <li>Ensure MySQL is running</li>
                                    <li>Import the database schema:
                                        <code>mysql -u root -p &lt; database/schema.sql</code>
                                    </li>
                                    <li>Or use phpMyAdmin to import <code>database/schema.sql</code></li>
                                    <li>Update database credentials in <code>config/database.php</code></li>
                                </ol>

                                <h6>PHP Extensions:</h6>
                                <p>Install missing PHP extensions through your PHP installation or web server (XAMPP/WAMP).</p>

                                <h6>File Permissions:</h6>
                                <p>Ensure the web server has write permissions to the logs directory.</p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Demo Accounts -->
                        <?php if ($overall_status): ?>
                        <div class="card bg-light mt-4">
                            <div class="card-header">
                                <h5><i class="fas fa-users me-2"></i>Demo Accounts</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="card bg-primary text-white">
                                            <div class="card-body text-center">
                                                <h6>Doctor Account</h6>
                                                <p class="mb-1"><strong>Username:</strong> dr_smith</p>
                                                <p class="mb-0"><strong>Password:</strong> password</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card bg-success text-white">
                                            <div class="card-body text-center">
                                                <h6>Patient Account</h6>
                                                <p class="mb-1"><strong>Username:</strong> patient_001</p>
                                                <p class="mb-0"><strong>Password:</strong> password</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card bg-info text-white">
                                            <div class="card-body text-center">
                                                <h6>Admin Account</h6>
                                                <p class="mb-1"><strong>Username:</strong> admin</p>
                                                <p class="mb-0"><strong>Password:</strong> password</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- System Information -->
                        <div class="mt-4">
                            <h6>System Information</h6>
                            <ul class="list-unstyled">
                                <li><strong>PHP Version:</strong> <?php echo $php_version; ?></li>
                                <li><strong>Server:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></li>
                                <li><strong>Document Root:</strong> <?php echo $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown'; ?></li>
                                <li><strong>Current Time:</strong> <?php echo date('Y-m-d H:i:s'); ?></li>
                            </ul>
                        </div>

                        <div class="text-center mt-4">
                            <button onclick="location.reload()" class="btn btn-outline-primary">
                                <i class="fas fa-sync-alt me-2"></i>Refresh Check
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
